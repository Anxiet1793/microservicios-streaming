# Deuda técnica

| Prioridad | Tema | Brecha | Acción |
| --- | --- | --- | --- |
| P0 | Credencial histórica | Revocación externa no acreditada | Confirmar con propietario; no probar ni exportar secreto |
| P1 | JWT/JWKS y presignado | Logout no invalida inmediatamente todas las credenciales externas | TTL reducido/rotación solapada y despliegue TLS |
| P1 | Huérfanos de media | Upload storage/DB y publicación Catalog no son transacción global | Reconciliación y retención futura |
| P1 | Outbox PENDING | No hay dispatcher/retry/consumer | Diseñar entrega idempotente antes de Recommendations |
| P1 | Avisos MODERATE | Drizzle Kit y MinIO transitivos según corte | Revisión de compatibilidad y actualización validada |
| P1 | Estado sin commit final | No reproducible solo con HEAD remoto | Publicar código evaluado y asociar run CI |
| P2 | Rendimiento/HA | Sin campaña de carga ni restore validado | Medir con datos/criterios antes de afirmar escalabilidad |
| P2 | Navegadores y accesibilidad | E2E Chromium; campaña completa pendiente | Firefox/WebKit, teclado y lector |

La deuda no se cierra modificando el README: requiere código/configuración, pruebas y evidencia de operación. Este trabajo documental no implementa esas mejoras.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
