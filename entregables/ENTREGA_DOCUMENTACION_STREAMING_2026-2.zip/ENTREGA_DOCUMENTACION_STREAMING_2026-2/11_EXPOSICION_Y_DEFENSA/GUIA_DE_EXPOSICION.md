# Guía de exposición académica

Propuesta de 12 minutos: problema/decisión 3 min, DDD 3 min, demo 3 min y calidad/CI 3 min. No constituye una duración exigida por una rúbrica oficial no localizada.

Integrante 1 explica el problema, contrasta monolito modular y microservicios y muestra C4 Context/Container. Integrante 2 presenta contextos, agregados, reglas y datos independientes, con ERD/modelos y Context Map. Integrante 3 dirige la demo y resume calidad; el integrante 1 vuelve para explicar CI/limitaciones si conviene equilibrar la participación. Los nombres y contribuciones reales deben completarse con evidencia del equipo.

Cerrar con un límite concreto: las tres APIs y el recorrido funcionan; Recommendations/Pagos/bus/CD productivo no se presentan como completados. Mostrar cifras solo desde el corte vigente y reconocer el CI remoto pendiente. Preparar capturas de respaldo por si no hay red/Docker durante la exposición.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **PROPUESTA DE EXPOSICIÓN**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
