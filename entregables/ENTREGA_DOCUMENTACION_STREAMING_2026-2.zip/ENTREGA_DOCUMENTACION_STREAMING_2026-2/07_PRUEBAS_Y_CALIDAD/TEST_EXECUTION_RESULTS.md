# Resultados de ejecución del paquete

Se repitieron realmente las suites sobre el código disponible el 21/10/2026, con Node 24.21.0, npm 12.2.0, Windows y Docker Linux. Estos resultados son el **corte principal del paquete**; Evidencia_EP conserva una ejecución anterior sin sobrescribirla. Cada proyecto ejecutó lint, typecheck, test:coverage y docs:check donde existe.

| Proyecto | Total | Passed | Failed | Skipped | Inicio UTC |
| --- | --- | --- | --- | --- | --- |
| frontend | 65 | 65 | 0 | 0 | 2026-10-21T21:21:27.805000+00:00 |
| users-service | 96 | 96 | 0 | 0 | 2026-10-21T21:21:29.802000+00:00 |
| catalog-service | 103 | 103 | 0 | 0 | 2026-10-21T21:21:25.353000+00:00 |
| playback-service | 115 | 115 | 0 | 0 | 2026-10-21T21:21:25.384000+00:00 |

Total Vitest: **379**, passed **379**, failed **0**, skipped **0**. Los grupos de integración/API/contrato ya están incluidos en cada total.

Playwright: **12 aprobados**, unexpected 0, skipped 0, flaky 0; retries configurados en cero. Tiempo Playwright 61.493 s; comando completo 115.254 s con builds/startup/cleanup.

Bruno: 59/59 peticiones y 227/227 tests. No se suman al total Vitest. Smoke: consultar log root-stack-2, no inferirlo del health anónimo.

[Comandos/exit codes/timestamps](Ejecucion_actual/commands.json) · [E2E](Ejecucion_actual/e2e-results.json) · [Demo](Ejecucion_actual/demo-results.json). Todos los comandos registrados del corte principal devolvieron 0. No se cambiaron reglas de negocio ni se usó || true para forzar éxito. Los builds host y el dossier EP anterior están diferenciados; el E2E y Compose volvieron a construir las imágenes actuales.
