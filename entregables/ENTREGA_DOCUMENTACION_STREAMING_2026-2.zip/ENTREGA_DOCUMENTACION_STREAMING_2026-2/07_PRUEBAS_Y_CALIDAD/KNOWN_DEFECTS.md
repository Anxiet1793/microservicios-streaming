# Defectos conocidos y límites

No afirmar «cero defectos» por pasar las suites. Los hallazgos vigentes se clasifican como riesgos o pendientes: credencial histórica con revocación externa no acreditada; avisos MODERATE transitivos; CSP inline; rate limiting Catalog; rotación JWKS; URL firmada reutilizable hasta TTL; Outbox sin dispatcher; reconciliación de objetos huérfanos; cobertura BFF y campañas de accesibilidad/carga/restore.

QUALITY_AUDIT y TEST_MATRIX originales son históricos: pueden describir carencias ya corregidas por el hardening/tests posteriores. El estado actual se contrasta con resultados recientes y código. No se conoce un número total de defectos abiertos mantenido en un tracker; usar NO DISPONIBLE. Si aparece un fallo durante el empaquetado, registrar comando/log sin silenciarlo ni cambiar lógica de negocio para conseguir verde.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [docs/quality/SECURITY_REVIEW.md](../07_PRUEBAS_Y_CALIDAD/Antecedentes/SECURITY_REVIEW.md)
- [docs/quality/DEPENDENCY_AUDIT.md](../07_PRUEBAS_Y_CALIDAD/Antecedentes/DEPENDENCY_AUDIT.md)
