# Índices y optimizaciones

Los índices únicos protegen invariantes además de acelerar acceso: users.email/user_id, refresh hash, PK compuestas de lista/preferencia, tituloId/importKey, assetId/sessionId y usuario–título en progreso. Catalog usa filtros estado/tipo, año, género y texto; la consulta paginada tiene límites. Playback indexa continuidad e historial por usuario/actividad y aplica TTL a buckets de cuota.

No se afirma que exista un índice que garantice unicidad global de todas las sesiones activas: la lógica serializa mediante transacción/touch del asset y guarda sesiones sustituidas. No se midieron planes de consulta con volumen productivo. Los índices completos están en los JSON de modelos y en el esquema SQL; «optimización» aquí describe intención y controles, no un benchmark.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/src/modules/users/infrastructure/persistence/schema.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/infrastructure/persistence/schema.ts)
- [playback-service/src/modules/playback/infrastructure/mongo.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/infrastructure/mongo.ts)
- [catalog-service/src/modules/catalog/infrastructure/persistence/mongodb/indexes/catalog-indexes.ts](../13_MATERIAL_DE_REFERENCIA/fuentes/6a98b837fc_catalog-indexes.ts)
