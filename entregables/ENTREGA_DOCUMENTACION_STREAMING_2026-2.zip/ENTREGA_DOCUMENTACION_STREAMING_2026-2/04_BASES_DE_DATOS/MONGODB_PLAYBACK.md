# Modelo MongoDB de Playback

Modelos extraídos de los validadores e índices actuales. No son un dump de datos. En Playback el validador no declara tipos de todos los campos: se distingue el tipo del modelo TypeScript de la garantía BSON. Catalog usa objetos cerrados/Int32; Playback permite campos no enumerados en propiedades según el validador actual.

## media_assets

| Campo BSON | Tipo validado | Requerido | Restricciones |
| --- | --- | --- | --- |
| assetId | string | SI | {} |
| sizeBytes | ['double', 'int', 'long'] | SI | {"minimum": 0} |
| durationSeconds | ['double', 'int', 'long'] | SI | {"minimum": 0} |
| status | enum | SI | {"enum": ["READY", "DELETED"]} |
| createdAt | date | SI | {} |
| updatedAt | date | SI | {} |

### Índices

```json
[
  {
    "keys": {
      "assetId": 1
    },
    "unique": true
  }
]
```

## playback_sessions

| Campo BSON | Tipo validado | Requerido | Restricciones |
| --- | --- | --- | --- |
| status | enum | SI | {"enum": ["REQUESTED", "ACTIVE", "PAUSED", "COMPLETED", "FAILED"]} |
| progress | object | SI | {"required": ["positionSeconds", "durationSeconds", "percentage", "updatedAt"]} |
| progress.positionSeconds | ['double', 'int', 'long'] | SI | {"minimum": 0} |
| progress.durationSeconds | ['double', 'int', 'long'] | SI | {"minimum": 0} |
| progress.percentage | ['double', 'int', 'long'] | SI | {"minimum": 0, "maximum": 100} |
| progress.updatedAt | date | SI | {} |
| startedAt | date | SI | {} |
| lastActivityAt | date | SI | {} |

### Índices

```json
[
  {
    "keys": {
      "sessionId": 1
    },
    "unique": true
  },
  {
    "keys": {
      "assetId": 1,
      "status": 1
    }
  }
]
```

## playback_progress

| Campo BSON | Tipo validado | Requerido | Restricciones |
| --- | --- | --- | --- |
| progress | object | SI | {"required": ["positionSeconds", "durationSeconds", "percentage", "updatedAt"]} |
| progress.positionSeconds | ['double', 'int', 'long'] | SI | {"minimum": 0} |
| progress.durationSeconds | ['double', 'int', 'long'] | SI | {"minimum": 0} |
| progress.percentage | ['double', 'int', 'long'] | SI | {"minimum": 0, "maximum": 100} |
| progress.updatedAt | date | SI | {} |
| status | enum | SI | {"enum": ["IN_PROGRESS", "COMPLETED"]} |
| continueWatching | bool | SI | {} |
| lastActivityAt | date | SI | {} |

### Índices

```json
[
  {
    "keys": {
      "userId": 1,
      "tituloId": 1
    },
    "unique": true
  },
  {
    "keys": {
      "userId": 1,
      "lastActivityAt": -1,
      "tituloId": 1
    }
  },
  {
    "keys": {
      "userId": 1,
      "continueWatching": 1,
      "lastActivityAt": -1,
      "tituloId": 1
    }
  }
]
```

## outbox_events

| Campo BSON | Tipo validado | Requerido | Restricciones |
| --- | --- | --- | --- |
| version | enum | SI | {"enum": [1]} |
| occurredAt | date | SI | {} |
| deliveryStatus | enum | SI | {"enum": ["PENDING", "DELIVERED"]} |

### Índices

```json
[
  {
    "keys": {
      "eventId": 1
    },
    "unique": true
  },
  {
    "keys": {
      "deliveryStatus": 1,
      "occurredAt": 1
    }
  }
]
```

## rate_limit_buckets

| Campo BSON | Tipo validado | Requerido | Restricciones |
| --- | --- | --- | --- |
| key | string | SI | {} |
| count | ['double', 'int', 'long'] | SI | {"minimum": 0} |
| expiresAt | date | SI | {} |

### Índices

```json
[
  {
    "keys": {
      "key": 1
    },
    "unique": true
  },
  {
    "keys": {
      "expiresAt": 1
    },
    "expireAfterSeconds": 0
  }
]
```

Los campos adicionales del modelo de aplicación son: media_assets: objectKey, bucket, contentType, originalFilename, codec, width, height y referenceRevision; playback_sessions: userId/tituloId/assetId/sessionId strings, completedAt/supersededAt nullable Date y emittedMilestone number; playback_progress: lastSessionId y demás IDs strings; outbox_events: eventId/eventType/userId/tituloId strings, data={sessionId,completionPercentage,watchTimeSeconds:null}. El validador de Outbox admite PENDING/DELIVERED, pero el publisher actual solo inserta PENDING; no hay código dispatcher que entregue.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [playback-service/src/modules/playback/infrastructure/mongo.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/infrastructure/mongo.ts)
