# Alcance de esta carpeta

La subcarpeta Documentacion_tecnica contiene el documento técnico disponible; no sustituye los informes formales faltantes.
