# Cobertura del corte principal

| Proyecto | Líneas | Statements | Branches | Functions |
| --- | --- | --- | --- | --- |
| frontend | 81,22% | 79,60% | 72,16% | 69,38% |
| users-service | 95,28% | 93,45% | 91,05% | 88,96% |
| catalog-service | 88,14% | 86,83% | 82,80% | 91,11% |
| playback-service | 86,89% | 84,32% | 78,22% | 86,91% |

Las cifras proceden de JSON summary V8 recién generado. Los HTML completos están en Reportes_HTML/<proyecto>/index.html. Los JSON por archivo conservan numerador/denominador. Frontend incluye componentes/features/cliente API/modelos seleccionados; **no todo el BFF/server ni todas las rutas Next**. Backend incluye src/**/*.ts. No se instrumentó coverage de navegador E2E ni se obtiene un promedio global mezclando bases de medición distintas.

Pasaron los thresholds actuales: frontend 75% líneas/statements y 65% branches/functions; backends 70% global y 80% domain/application. Persisten ramas no cubiertas, especialmente en código de interfaz, wiring y adapters. Coverage no es porcentaje de requisitos completos ni prueba de ausencia de defectos.
