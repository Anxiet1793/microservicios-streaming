# Guion de demostración

Preparar el Compose con antelación y ejecutar smoke. No mostrar .env, headers Authorization, cookies o la consola MinIO con credenciales. Utilizar las cuentas sintéticas del seed y un título reproducible propio.

1. Entrar como USER y mostrar catálogo/detalle. Explicar que Users autentica y Catalog es dueño de la ficha.
2. Agregar Mi Lista y marcar LIKE; abrir Mi Lista para demostrar persistencia por referencia.
3. Preparar reproducción, mostrar el MP4, avanzar unos segundos y pausar.
4. Volver a Continuar viendo y retomar cerca de la posición guardada; completar y mostrar historial.
5. Si queda tiempo, entrar ADMIN y mostrar carga/publicación ya ensayada; el archivo de demostración es pequeño y sintético.

Recorrido completo automatizado alternativo: npm run api:demo:cleanup. Las capturas de 09 respaldan cada paso; no reemplazar una caída real durante la exposición por una imagen y afirmar que fue ejecución en vivo. Si algo falla, mostrar error controlado y usar la evidencia fechada como respaldo explícito.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **GUION BASADO EN FUNCIONES VERIFICADAS**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
