# Casos negativos documentados

Selección trazable por nombre de casos ejecutados, no una afirmación de cobertura exhaustiva de ataques. Incluye validación, permisos, replay, concurrencia, rollback, storage y recuperación. Las dependencias son reales o controladas según la suite; consultar TESTING_STRATEGY.

| Proyecto | Tipo | Archivo | Caso | Resultado |
| --- | --- | --- | --- | --- |
| frontend | unit | frontend/tests/unit/player.test.ts | ordered playback writes stops future writes when superseded | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return https://evil.example | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return //evil.example | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return /\evil | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return /api/bff/admin | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return /login?next=https://evil.example | passed |
| frontend | component | frontend/tests/component/actions.test.tsx | personal state under failure distinguishes a wrong current password from an expired session | passed |
| frontend | component | frontend/tests/component/actions.test.tsx | personal state under failure rolls back an optimistic watchlist toggle after a rejected write | passed |
| frontend | component | frontend/tests/component/actions.test.tsx | personal state under failure keeps an incomplete paginated state unknown rather than enabling neutral actions | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | rejects a non MP4 before starting a network transfer | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | retains a stable import key after a rejected ficha and publishes without uploading twice | passed |
| frontend | component | frontend/tests/component/auth.test.tsx | does not dispatch a session-expiry event for a rejected login | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | MediaCard uses catalog IDs, metadata and an image fallback on load failure | passed |
| frontend | component | frontend/tests/component/personal.test.tsx | restores an existing item when optimistic removal fails | passed |
| frontend | component | frontend/tests/component/personal.test.tsx | changes LIKE to DISLIKE without deleting first and rolls back a failed change | passed |
| frontend | component | frontend/tests/component/player.test.tsx | reports playback service failure and allows opening another session | passed |
| frontend | component | frontend/tests/component/session.test.tsx | failed logout retains session, reports failure and enables retry | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects invalid registration (email) without writing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects invalid registration (password) without writing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects invalid registration (role injection) without writing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects invalid registration (empty profile) without writing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled returns generic login error for wrong-password | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects a validly signed token whose user no longer exists | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects malformed identifiers, repeated pagination and protected preference fields | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled refresh requires CSRF proof, rotates cookie and rejects a reused family | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled responds safely to malformed bodies, foreign origin and unsupported methods | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios hace rollback de usuario si falla la inserción del perfil | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios impide emails duplicados incluso con registros concurrentes | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios dos refresh simultáneos no dejan una familia utilizable tras detectar replay | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios rechaza refresh vencido | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios creación de sesión rechaza credenciales obsoletas tras cambio de password | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios Mi Lista impide duplicados, pagina, elimina y aísla usuarios | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios expira ventanas de cuotas sin permitir que contadores previos bloqueen permanentemente | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados rechaza contraseña incorrecta, usuario inactivo y carrera con cambio de password | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados rota refresh y rechaza reutilización | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados rechaza versiones y roles falsos, usuarios inactivos y paginación excesiva | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"authVersion":0} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"authVersion":1.1} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"status":"DELETED"} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"role":"ROOT"} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"userId":"internal-id"} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"passwordHash":""} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"createdAt":null} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"updatedAt":"1970-01-01T00:00:00.000Z"} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects unsafe avatar/locale values while allowing regional language tags | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | requires HTTPS in production and rejects malformed or credential-bearing origins | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza email inválido  | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza email inválido bad | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza email inválido a@ | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza email inválido a b@example.com | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza contraseña inválida | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza contraseña inválida | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza contraseña inválida | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza campos protegidos, perfil vacío y URLs inseguras | passed |
| users-service | unit | users-service/tests/unit/security.test.ts | Seguridad refresh aleatorio almacenable como SHA-256 y rechaza tokens malformados | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS denies anonymous and USER before parsing or opening MongoDB | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS denies anonymous and USER before parsing or opening MongoDB | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS denies anonymous and USER before parsing or opening MongoDB | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"role":["ADMIN"]} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"iat":"invalid"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"iat":1792617758} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"iat":1792614098} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"role":"ROOT"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"role":null} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"jti":123} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"jti":""} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"sub":"internal-id"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"userId":"another-user"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"iss":"evil"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"aud":"evil"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"exp":1} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"nbf":1792621298} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects invalid protected headers {"typ":"NOT-JWT"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects invalid protected headers {"kid":"other"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects bad signatures, unsigned tokens, HS256 and oversized authorization | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS fails closed on JWKS outage and refuses credentialed or non-HTTP key URLs | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary accepts the configured maximum exactly and rejects maximum+1 without writes | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary does not persist an entirely invalid batch | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary maps duplicate retries, conflicting import keys and uncertain outcomes truthfully | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?limit=101 before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?page=1&page=2 before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?status=99 before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?genre[$ne]=1 before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?q=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary distinguishes invalid identity from a valid identity that does not exist | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary updates only editorial fields and rejects protected fields without persisting | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary publishes, withdraws and repeats status idempotently without forbidden transitions | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary health and queries fail safely when persistence is unavailable | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects malformed JSON and provides method metadata without leaking internals | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas distingue duplicados, conflictos y resultados indeterminados | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas actualiza la ficha, omite no-op y propaga conflictos concurrentes | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"version":0} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"version":1.5} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"version":2147483648} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"updatedAt":"1970-01-01T00:00:00.000Z"} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"createdAt":null} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | prevents version overflow and invalid/regressive modification dates | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"providerId":999} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"assetId":" "} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"manifestKey":""} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"assetId":"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"url":"https://attacker.test"} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza la transición 1→3 | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza la transición 2→1 | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza la transición 3→1 | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza la transición 3→2 | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"title":" "} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"releaseYear":1887} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"releaseYear":2025.5} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"genres":[1,1]} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"genres":[999]} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"languages":["1"]} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"durationMinutes":0} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"posterUrl":"javascript:alert(1)"} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"posterUrl":"https://user:password@example.com/image"} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"title":"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"publicationStatusId":2} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza ObjectId como identificador público | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas rechaza operadores, campos internos e IDs como cadenas | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado reconoce reintentos y no sobrescribe contenido por conflicto de importKey | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado resuelve repetidos del lote y rechaza grupos con contenido contradictorio | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado aplica PATCH real y rechaza una escritura con versión obsoleta | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports rejects caller identity injection, invalid positions and malformed route IDs | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports rejects USER asset access and permits ADMIN metadata and soft delete | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports maps missing/unpublished/catalog-down/storage-down start failures safely | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports returns a safe JSON failure even when container configuration cannot be constructed | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP rejects incompatible payload {} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP rejects incompatible payload {"tituloId":"wrong","publicationStatusId":2,"playbackReference":null} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP rejects incompatible payload {"tituloId":"ttl_cf0ed81e-3fc4-41e6-ba71-e52a6a298f45","publicationStatusId":"2","playbackReference":null} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"iss":"wrong"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"aud":"wrong"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"exp":1} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"sub":"usr_2b583c2c-2676-487f-84b8-ffcce577b93f"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"userId":"forged"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"role":"ROOT"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"role":["ADMIN"]} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"iat":"invalid"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"iat":1792617754} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"iat":1792614094} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"jti":42} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"jti":""} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"nbf":1792621294} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible headers {"kid":"unknown-key"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible headers {"typ":"NOT-JWT"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects an invalid signature while retaining the advertised kid | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects a JWKS with invalid RSA key material | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract fails closed when the JWKS endpoint is unavailable | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects unsigned and symmetric algorithm confusion tokens | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set rolls back all writes when outbox publication fails | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set starts concurrently with only one current session and rejects the losing player's writes | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set rolls back progress and pause when outbox fails after a session already exists | passed |
| playback-service | integration | playback-service/tests/integration/storage.test.ts | rejects expired signed URLs and recognizes an object that has been removed | passed |
| playback-service | integration | playback-service/tests/integration/storage.test.ts | does not treat denied storage credentials as a missing object | passed |
| playback-service | unit | playback-service/tests/unit/config.test.ts | validates runtime config without leaking invalid secrets | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress rejects invalid position -1 | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress rejects invalid position NaN | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress rejects invalid position Infinity | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress rejects invalid position 123 | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases allows ACTIVE -> FAILED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects COMPLETED -> ACTIVE | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects FAILED -> ACTIVE | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects REQUESTED -> COMPLETED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects PAUSED -> FAILED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects unpublished title | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects missing asset | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases continues at persisted position and supersedes old session | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases supersedes a paused session without introducing a forbidden state transition | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | rejects invalid persisted duration 0 | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | rejects invalid persisted duration -1 | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | rejects invalid persisted duration NaN | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | rejects invalid persisted duration Infinity | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | compensates successful storage upload when metadata insertion fails | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | does not report successful upload when compensation also fails | passed |

La demo exige HTTP 400/401/403/404/409/415 en sus negativos; un error esperado significa aserción aprobada, no test fallido. E2E detiene solo Catalog/Playback/Redis de su stack exclusivo y comprueba recuperación.
