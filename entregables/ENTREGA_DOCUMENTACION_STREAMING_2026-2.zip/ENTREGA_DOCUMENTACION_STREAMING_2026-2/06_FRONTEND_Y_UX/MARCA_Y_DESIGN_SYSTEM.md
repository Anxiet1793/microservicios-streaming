# Marca y sistema visual

Marca observada: **NÉVARO**, tagline «Tu próxima historia empieza aquí». Es identidad creativa del proyecto, sin disponibilidad registral/comercial acreditada. El icono SVG disponible se conserva como activo real, no se diseña un logo nuevo para simular un entregable anterior.

Paleta implementada en tokens.css: fondo #0b1017, superficie #131c27, primario ámbar #f4c46b, secundario #9bb9e9, texto #f5f1e8 y secundario #b5c0ce. Tipografía Manrope autoalojada con fallback Arial/sans-serif; licencias existentes referidas en material técnico. Espaciado base 4 px, radios y motion definidos por variables CSS. Las propuestas históricas de marca/UI están en 01; el código/capturas determinan qué se implementó.

Responsive usa gutters/tipos fluidos y media queries observadas 768/1024/1280 px; existe preferencia reduced-motion. Las capturas desktop y mobile documentan resoluciones concretas, no una certificación WCAG ni compatibilidad universal.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [frontend/src/styles/tokens.css](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/styles/tokens.css)
- [frontend/src/lib/brand.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/brand.ts)
