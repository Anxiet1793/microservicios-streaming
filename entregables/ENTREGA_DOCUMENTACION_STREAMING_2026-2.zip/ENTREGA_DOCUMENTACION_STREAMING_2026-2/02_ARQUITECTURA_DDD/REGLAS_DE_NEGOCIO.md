# Reglas de negocio

| ID | Regla | Fuente/prueba asociada |
| --- | --- | --- |
| RN01 | Registro normal crea ACTIVE/USER; email trim/lower y único | Users dominio/SQL/API |
| RN02 | Password 12–128 caracteres Unicode, sin NUL; Argon2id | Users dominio/security |
| RN03 | Perfil no cambia userId, status, role ni hashes | Users schema/dominio |
| RN04 | Mi Lista y preferencia únicas por usuario/título; sin FK externa | SQL/repositories |
| RN05 | Refresh rotatorio de un uso; replay revoca familia; password revoca sesiones | Users integración |
| RN06 | Película requiere duración y referencia; serie no admite referencia propia | TituloCatalogo/validador |
| RN07 | ImportKey idempotente; input distinto con misma clave no sobrescribe | Catalog bulk/fingerprint |
| RN08 | Retirada terminal en el dominio actual; PATCH ficha no publica | EstadoPublicacion |
| RN09 | Asset upload/metadatos/borrado ADMIN; MP4 inspeccionado | Playback HTTP/use cases |
| RN10 | Solo propietario modifica su sesión; sesión sustituida no escribe | PlaybackSession |
| RN11 | Solo ACTIVE/PAUSED guarda progreso; COMPLETED termina el recorrido | PlaybackSession |
| RN12 | Continue Watching excluye completados y avance igual o superior al umbral de 90% | Playback casos de uso/proyección |
| RN13 | Borrado no permite asset con sesión abierta | Playback repositorio/transacción |
| RN14 | Sesión/progreso/evento se confirman en transacción Mongo local | UnitOfWork/Outbox |

La matriz de tests enlaza casos aprobados; no significa que toda combinación posible de entradas esté cubierta.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
- [playback-service/src/modules/playback/application/use-cases.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/application/use-cases.ts)
- [playback-service/src/modules/playback/infrastructure/mongo.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/infrastructure/mongo.ts)
