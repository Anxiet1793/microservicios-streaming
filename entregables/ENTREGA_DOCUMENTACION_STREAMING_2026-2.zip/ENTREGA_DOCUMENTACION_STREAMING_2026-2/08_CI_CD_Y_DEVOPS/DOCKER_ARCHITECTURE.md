# Arquitectura Docker

El Compose raíz incluye frontend, users-service/users-postgres, catalog-service/catalog-mongodb, playback-service/playback-mongodb, MinIO y Redis. Inicializadores: users-migrate, users-seed, catalog-init, playback-replica-init, playback-init y stack-seed. Startup usa health/completion; la inicialización del replica set se apoya en service_started para no esperar un PRIMARY que aún debe configurar.

Hay redes internas backplane, users-data, catalog-data, playback-data y sessions, más edge con puertos loopback. Solo el propietario se conecta a su red de datos; frontend usa APIs/Redis. Volúmenes guardan SQL, Mongo, S3, Redis y estado seed. Los Dockerfiles de aplicaciones usan multistage/standalone y usuario no root. Es un entorno de desarrollo de un nodo, no topología productiva.

El snapshot Docker registra nombre/estado/imagen/puertos; los logs completos de ENV resuelto no se empaquetan. Para revisar sintaxis usar `docker compose config --quiet`; la variante sin quiet puede mostrar secretos.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [docker-compose.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/docker-compose.yml)
- [frontend/Dockerfile](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/Dockerfile)
- [users-service/Dockerfile](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/Dockerfile)
- [catalog-service/Dockerfile](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/Dockerfile)
- [playback-service/Dockerfile](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/Dockerfile)
