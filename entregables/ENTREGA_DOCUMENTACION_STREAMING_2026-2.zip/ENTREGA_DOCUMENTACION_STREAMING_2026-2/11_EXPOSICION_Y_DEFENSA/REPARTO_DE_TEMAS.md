# Propuesta de reparto

| Bloque | Tiempo propuesto | Participación propuesta | Material |
| --- | --- | --- | --- |
| Problema/alternativas | 3 min | Integrante 1 | C4 y comparación |
| DDD/datos | 3 min | Integrante 2 | Context Map, agregados, ERD |
| Demo | 3 min | Integrante 3 | UI + guion y capturas |
| Calidad/CI/límites | 3 min | Integrantes 1 y 3 | Resultados, pipeline, pendientes |

No se asignan nombres ni autoría no proporcionados. Completar luego de acuerdo del equipo.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **PROPUESTA, NO REGISTRO DE CONTRIBUCIONES**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
