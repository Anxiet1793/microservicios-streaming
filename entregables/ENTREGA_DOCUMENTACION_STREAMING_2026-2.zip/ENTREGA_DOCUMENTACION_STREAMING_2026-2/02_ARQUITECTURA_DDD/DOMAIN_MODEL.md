# Modelo de dominio

| Contexto | Modelo | Datos | Responsabilidad |
| --- | --- | --- | --- |
| Usuarios | Usuario | UserId externo, email, hash, estado, rol, perfil, authVersion | Integridad de identidad y acceso |
| Catálogo | TituloCatalogo | TituloId, typeId, ficha, estado, referencia, versión | Ficha editorial e importación/publicación |
| Reproducción | PlaybackSession | Sesión, propietario, título/asset, estado y progreso | Transición/propiedad y continuidad |
| Reproducción | MediaAsset / ConsolidatedProgress | Modelos de soporte con repositorios propios | Archivo disponible y última proyección por usuario/título |

El modelo conceptual de cinco bounded contexts no obliga a crear cinco proyectos. Recomendaciones/Pagos carecen de agregados ejecutables actuales. Perfil pertenece al ciclo de vida de Usuario; su tabla separada no lo convierte en otro agregado. Watchlist/preferencias usan puertos propios para no cargar colecciones crecientes al restaurar Usuario. MediaAsset y progreso son interfaces/modelos reales de Playback, no clases de agregado equivalentes a Usuario.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
