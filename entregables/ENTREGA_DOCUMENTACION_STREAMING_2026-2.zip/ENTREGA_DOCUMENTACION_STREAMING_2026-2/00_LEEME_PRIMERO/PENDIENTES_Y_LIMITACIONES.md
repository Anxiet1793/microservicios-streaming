# Pendientes y límites del expediente

1. Rúbrica oficial e informes formales Word/PDF de Dinámicas 1/2 no localizados. Obtener del campus/equipo y conservar originales; la matriz es provisional.
2. Integrantes/contribuciones no proporcionados. Completar con commits/actas verificables; no atribuir autoría por suposición.
3. Git contiene un commit base y trabajo local posterior. Publicar el código evaluado y asociar un run CI; el expediente contiene referencias/extractos, no un clon ejecutable íntegro.
4. Recomendaciones, Pagos, bus, dispatcher Outbox, gateway independiente y CD productivo no están implementados/verificados.
5. Conservar la distinción entre evidencia actual y antecedentes. Las cifras del corte actual se obtienen de Ejecucion_actual; el dossier EP es histórico del mismo día.
6. La revocación externa de una credencial histórica no se acredita. No se incluyó el blob ni se probó ese secreto.
7. Sin campaña de carga/HA/restore/accesibilidad completa ni pruebas de todos los navegadores. No inferir SLA o escalabilidad de los tiempos locales.
8. Algunos originales conservan enlaces relativos pensados para el repositorio. El índice de fuentes resuelve sus rutas originales al archivo curado; no se alteraron los originales para corregir su contexto histórico.
9. Capturas de video son de MP4 sintético; los placeholders de poster son UI real y no fallos ocultados con imágenes generadas. Las cuentas sintéticas creadas para screenshots permanecen porque no hay endpoint de borrado; el asset administrativo creado exclusivamente para capturar upload fue borrado por API después de confirmar su alta.
10. El calendario semanas 9–16 y el reparto de exposición son propuestas; el equipo debe validarlos con el docente.
