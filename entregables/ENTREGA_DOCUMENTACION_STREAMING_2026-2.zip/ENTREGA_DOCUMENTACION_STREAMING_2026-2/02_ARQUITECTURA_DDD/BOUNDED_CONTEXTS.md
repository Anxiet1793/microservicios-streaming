# Bounded Contexts

| Contexto | Propiedad | Excluye | Estado |
| --- | --- | --- | --- |
| Usuarios | Identidad, perfil, refresh, lista, preferencias | Ficha, segundos reproducidos, pagos | VERIFICADO |
| Catálogo | Ficha, publicación, importación, referencia a asset | Sesiones, usuarios, progreso | VERIFICADO |
| Reproducción | Assets, sesiones, progreso, historial, Outbox | Credenciales de usuarios y ficha completa | VERIFICADO |
| Recomendaciones | Cálculo de sugerencias futuro | No implementado | PLANIFICADO |
| Pagos | Cobros/entitlements futuros | No implementado | PLANIFICADO |

Un identificador externo no implica propiedad compartida de la entidad. Las tres APIs actuales son los límites de integración; no hay acceso directo a la base de otro contexto.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
- [docker-compose.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/docker-compose.yml)
