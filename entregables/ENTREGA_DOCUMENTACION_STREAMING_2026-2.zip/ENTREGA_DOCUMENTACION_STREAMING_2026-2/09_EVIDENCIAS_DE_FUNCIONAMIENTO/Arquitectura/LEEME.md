# Figuras de arquitectura

Para evitar duplicados, las 18 figuras se conservan en [03_DIAGRAMAS_E_IMAGENES](../../03_DIAGRAMAS_E_IMAGENES/GUIA_DE_DIAGRAMAS.md), con PNG, SVG y fuente Mermaid editable. Son ilustraciones técnicas derivadas de código, distintas de las capturas de funcionamiento.
