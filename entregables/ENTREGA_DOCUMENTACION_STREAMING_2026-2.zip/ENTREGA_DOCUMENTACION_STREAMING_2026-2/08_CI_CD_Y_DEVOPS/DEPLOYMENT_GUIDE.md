# Guía de ejecución local

## Arranque del código completo evaluado

Requiere Git, Node 24/npm y Docker Desktop Linux con Compose. El ZIP no contiene un clon completo ni claves. Obtener el working tree indicado y publicar su commit final antes de prometer reproducción remota.

```sh
npm run stack:setup
docker compose up --build --detach --wait --wait-timeout 300
npm run smoke
npm run api:install
npm run api:check
npm run api:demo:cleanup
```

stack:setup genera localmente credenciales independientes y par RSA si no existe ENV; no sobreescribe un .env existente. Las cuentas admin@streaming.local/demo@streaming.local son sintéticas y usan SEED_PASSWORD generado en esa instalación. Obtener ese valor localmente, no enviarlo con el informe. Seed genera/carga MP4 sintético de 12 s y publica un título. No depende de una cuenta personal ni video de terceros.

UI http://localhost:8080, Users 8081, Catalog 8082, Playback 8083; MinIO 9000 y consola 9001. Login ADMIN permite /admin. No cambiar ENV de contraseñas reteniendo volúmenes sin plan de migración: cambiar el archivo no altera cuentas ya creadas.

```sh
npm run stack:logs
docker compose ps --all
npm run stack:down
```

stack:down conserva datos. No ejecutar `down --volumes` salvo decisión explícita de borrar todos los datos del entorno local. Para tests usar runners aislados, no detener servicios compartidos manualmente.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [README.md](../13_MATERIAL_DE_REFERENCIA/repositorio/README.md)
- [scripts/setup-stack.mjs](../13_MATERIAL_DE_REFERENCIA/repositorio/scripts/setup-stack.mjs)
- [scripts/stack.mjs](../13_MATERIAL_DE_REFERENCIA/repositorio/scripts/stack.mjs)
- [scripts/seed-stack.mjs](../13_MATERIAL_DE_REFERENCIA/repositorio/scripts/seed-stack.mjs)
