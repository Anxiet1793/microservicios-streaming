# Estado técnico vigente

| Componente | Estado | Alcance |
| --- | --- | --- |
| Frontend/BFF | VERIFICADO MEDIANTE PRUEBA | UI/SSR, composición, Redis, auth y panel ADMIN; E2E y capturas reales |
| Usuarios | VERIFICADO MEDIANTE PRUEBA | Perfil, sesiones, Mi Lista, LIKE/DISLIKE, PostgreSQL |
| Catálogo | VERIFICADO MEDIANTE PRUEBA | Películas/series como ficha, importación, publicación; MongoDB |
| Reproducción | VERIFICADO MEDIANTE PRUEBA | MP4 H264, sesiones, progreso, historial, S3 presignado |
| Episodios de series | IMPLEMENTADO PARCIAL | Colección/validador/índices preparados; sin API pública ni reproductor de episodios |
| Outbox | IMPLEMENTADO Y PROBADO LOCALMENTE | Escritura transaccional PENDING; no dispatcher ni entrega externa |
| Recommendations | PLANIFICADO | No proyecto, endpoint, algoritmo ni pantalla de recomendaciones calculadas |
| Payments | PLANIFICADO | No implementación ni transacciones de pago |
| Event Bus | PENDIENTE | Sin broker ni consumidor desplegado |
| API Gateway | PENDIENTE COMO SERVICIO INDEPENDIENTE | Existe BFF acotado en Next; no es un gateway general desplegado aparte |
| CI GitHub Actions | IMPLEMENTADO / REMOTO NO VERIFICADO | YAML y gates locales; consulta de runs disponible en evidencias |
| CD productivo | PLANIFICADO | Compose de desarrollo; no despliegue automático de producción acreditado |

Consultar resultados vigentes de 07. No equiparar «implementado» con validación remota/productiva.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
