# Diccionario de datos para tablas

CSV UTF-8 con BOM y separador coma, celdas con escape estándar; JSON UTF-8. No convertir NO DISPONIBLE/NO VERIFICADO en cero. porcentajes de cobertura se expresan de 0 a 100 y conservan su denominador en JSON. duration_ms es milisegundos; duration_seconds es segundos; fechas son ISO UTC salvo etiqueta explícita Lima. test total/passed/failed/skipped son casos, no assertions individuales ni endpoints.

INVENTARIO_MICROSERVICIOS separa componentes presentes/futuros. TECNOLOGIAS usa versiones declaradas: ^/~ es un rango, no una medida instalada. ENDPOINTS es el contrato público backend, no todas las rutas BFF. CASOS_DE_PRUEBA identifica nombre, archivo, tipo y estado ejecutado. RESULTADOS_TEST no suma categorías dentro del mismo proyecto dos veces. REQUISITOS y ROADMAP son provisionales; CONTRIBUCIONES no atribuye trabajo a personas desconocidas. RIESGOS expresa prioridad técnica, no probabilidad estadística medida.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **DICCIONARIO Y UNIDADES**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
