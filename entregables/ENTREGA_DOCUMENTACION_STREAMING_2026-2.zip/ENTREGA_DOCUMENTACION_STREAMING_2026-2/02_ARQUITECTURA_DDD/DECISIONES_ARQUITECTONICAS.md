# Decisiones arquitectónicas

| ID | Decisión observada | Motivo técnico | Costo/limitación |
| --- | --- | --- | --- |
| ADR01 | Persistencia por contexto | Autonomía y garantías locales | Más operación y consistencia entre referencias |
| ADR02 | Drizzle/PostgreSQL en Users | Unicidad, transacciones, FOR UPDATE y cuotas | SQL visible/migraciones a mantener |
| ADR03 | MongoDB en Catalog | Ficha embebida y bulk con validators/indexes | Optimistic concurrency y límites explícitos |
| ADR04 | Mongo replica set en Playback | Transacción sesión/progreso/Outbox | Replica set de desarrollo de un nodo |
| ADR05 | MP4 directo MinIO presignado | No transportar video por Next | TTL, acceso de red y credencial URL temporal |
| ADR06 | RS256/JWKS | No compartir clave privada entre APIs | Caché, disponibilidad y rotación pendiente |
| ADR07 | BFF y Redis | Tokens fuera del JS y refresh coordinado | Redis agrega dependencia operacional |
| ADR08 | Outbox local sin bus | Preparar eventos sin simular consumidores | No hay entrega externa garantizada |
| ADR09 | UUIDv4 con prefijo | Contrato estable sin ObjectId/bigint externos | Índices y validación por prefijo |

Registro retrospectivo derivado del código y documentación; no son actas firmadas ni ADR históricos fechados por el equipo.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
- [frontend/src/lib/server/session.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/session.ts)
- [docker-compose.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/docker-compose.yml)
