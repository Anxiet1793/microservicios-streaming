# Estado actual del sistema

| Componente | Estado | Evidencia o límite |
| --- | --- | --- |
| Frontend/BFF | VERIFICADO MEDIANTE PRUEBA | UI/SSR, composición, Redis, auth y panel ADMIN; E2E y capturas reales |
| Usuarios | VERIFICADO MEDIANTE PRUEBA | Perfil, sesiones, Mi Lista, LIKE/DISLIKE, PostgreSQL |
| Catálogo | VERIFICADO MEDIANTE PRUEBA | Películas/series como ficha, importación, publicación; MongoDB |
| Reproducción | VERIFICADO MEDIANTE PRUEBA | MP4 H264, sesiones, progreso, historial, S3 presignado |
| Episodios de series | IMPLEMENTADO PARCIAL | Colección/validador/índices preparados; sin API pública ni reproductor de episodios |
| Outbox | IMPLEMENTADO Y PROBADO LOCALMENTE | Escritura transaccional PENDING; no dispatcher ni entrega externa |
| Recommendations | PLANIFICADO | No proyecto, endpoint, algoritmo ni pantalla de recomendaciones calculadas |
| Payments | PLANIFICADO | No implementación ni transacciones de pago |
| Event Bus | PENDIENTE | Sin broker ni consumidor desplegado |
| API Gateway | PENDIENTE COMO SERVICIO INDEPENDIENTE | Existe BFF acotado en Next; no es un gateway general desplegado aparte |
| CI GitHub Actions | IMPLEMENTADO / REMOTO NO VERIFICADO | YAML y gates locales; consulta de runs disponible en evidencias |
| CD productivo | PLANIFICADO | Compose de desarrollo; no despliegue automático de producción acreditado |

Las pruebas/capturas pertenecen al corte indicado en cada registro. El árbol contiene cambios locales anteriores al expediente; HEAD no representa por sí solo el código completo validado. Ver 13_MATERIAL_DE_REFERENCIA para hashes y trazabilidad.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **CORTE VIGENTE; SIN SERVICIOS FUTUROS PRESENTADOS COMO REALES**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
