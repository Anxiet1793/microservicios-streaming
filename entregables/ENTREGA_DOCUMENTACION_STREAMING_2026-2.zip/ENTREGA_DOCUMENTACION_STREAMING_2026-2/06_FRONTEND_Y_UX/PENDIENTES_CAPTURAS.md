# Capturas disponibles y pendientes

Hay capturas reales de login, registro/confirmación, Home desktop/mobile, catálogo, detalle, LIKE/Mi Lista, player pausado, continuar, perfil, ADMIN/listado/upload confirmado, retomar/completar/historial y reportes. Ver ../09_EVIDENCIAS_DE_FUNCIONAMIENTO/REGISTRO_EVIDENCIAS.md.

**No se capturó Recommendations** porque no existe ese servicio/pantalla. No hay captura verde de CI remoto porque no se verificó un run exitoso; aportar el enlace y captura del run del commit final cuando exista. Faltan capturas de dispositivos físicos/Firefox/WebKit y una campaña de accesibilidad; las imágenes actuales no simulan esas verificaciones. No se capturaron datos productivos ni credenciales.
