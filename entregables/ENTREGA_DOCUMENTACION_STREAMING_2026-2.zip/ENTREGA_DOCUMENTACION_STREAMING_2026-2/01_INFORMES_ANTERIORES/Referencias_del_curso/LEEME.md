# Alcance de esta carpeta

No se incorporaron diapositivas/consignas de otro curso como si fueran referencias de Arquitectura de Microservicios.
