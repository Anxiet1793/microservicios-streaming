# Pantallas y navegación

| Ruta | Función |
| --- | --- |
| /login | Inicio de sesión |
| /register | Registro |
| /home | Hero/carriles y continuar viendo |
| /explore | Búsqueda y filtros |
| /search | Resultado por query |
| /title/[tituloId] | Detalle y acciones |
| /watch/[tituloId] | Reproductor MP4 |
| /my-list | Mi Lista |
| /preferences | LIKE/DISLIKE |
| /continue-watching | Avance pendiente |
| /history | Historial |
| /profile | Perfil y password |
| /admin | Panel ADMIN |
| /admin/upload | Carga MP4 y publicación |
| /admin/content | Administración de títulos |

Las capturas de cada ruta están en 09_EVIDENCIAS_DE_FUNCIONAMIENTO y el registro identifica URL, fecha, dimensiones y comprobación. No se capturan recomendaciones porque no existe esa pantalla/servicio. El panel ADMIN muestra estados/carga reales. Que haya una ruta no acredita que cada branch de UI esté cubierto; consultar tests y límites.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [frontend/src/app/api/bff/[...path]/route.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/app/api/bff/[...path]/route.ts)
