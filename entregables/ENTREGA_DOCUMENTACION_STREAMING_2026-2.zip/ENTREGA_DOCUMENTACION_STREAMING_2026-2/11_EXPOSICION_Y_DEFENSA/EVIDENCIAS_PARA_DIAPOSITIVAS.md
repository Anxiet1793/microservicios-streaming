# Selección para diapositivas

Una diapositiva por bloque debe contener una idea y una evidencia. Usar C4 Container para arquitectura, Context Map/ERD para datos y una secuencia de player/continuar para demo. Para calidad usar RESULTADOS_TEST.csv con etiquetas de corte y el reporte real; para CI separar YAML/diagrama de run remoto. Las leyendas de figura deben citar ID del registro, fecha y tipo (captura real o ilustración técnica).

No agregar porcentajes inventados de avance del proyecto. No usar una pantalla Home para afirmar recomendaciones personalizadas: no existe ese servicio. No mostrar firmas temporales ni credenciales en capturas. El SVG permite reescalar diagramas; el PNG es la opción compatible para Word/PowerPoint.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **GUÍA EDITORIAL**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
