# Estrategia de pruebas

Vitest cubre unitarios/componentes/API/contrato y las integraciones reales de PostgreSQL, MongoDB y MinIO. React Testing Library prueba UI con puertos HTTP controlados. Los tests de contrato usan productores/HTTP locales según su suite; no equivalen todos a un despliegue completo.

Playwright crea un Compose aislado por ejecución, genera claves, cuentas y MP4, levanta servicios reales y limpia únicamente sus recursos. Prueba navegador Chromium, caídas de Catalog/Playback/Redis y continuidad de video. Bruno comprueba el flujo HTTP sobre el stack raíz y contratos JSON. Coverage V8 tiene un alcance de archivos definido, sin cobertura end-to-end del servidor Next.

Los resultados vigentes del paquete se conservan en Ejecucion_actual y se extraen de JSON/JUnit/logs nuevos. Evidencia_EP y Antecedentes mantienen cortes anteriores identificados. No sumar todos los reportes históricos como si fueran pruebas nuevas. Un error HTTP esperado en un caso negativo cuenta como test aprobado si cumple la aserción.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [frontend/vitest.config.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/vitest.config.ts)
- [frontend/playwright.config.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/playwright.config.ts)
- `users-service/vitest.coverage.config.ts` (ruta del repositorio; consultar índice de fuentes)
- [catalog-service/vitest.coverage.config.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/vitest.coverage.config.ts)
- `playback-service/vitest.coverage.config.ts` (ruta del repositorio; consultar índice de fuentes)
