# Guía para elaborar el informe y la defensa

## Ruta de lectura

1. Leer RESUMEN_EJECUTIVO y ESTADO_ACTUAL para fijar alcance.
2. Usar 02_ARQUITECTURA_DDD para el problema, alternativas, modelo de dominio y contexto.
3. Abrir GUIA_DE_DIAGRAMAS en 03; insertar PNG en Word/PowerPoint y conservar SVG/Mermaid para edición.
4. Consultar 04_BASES_DE_DATOS y los JSON de esquemas para tablas de campos/índices. No llamar «tabla» a un documento ni representar FK entre bases.
5. Utilizar 05_APIS_Y_CONTRATOS y ENDPOINTS.csv para el contrato REST y la demo.
6. Usar 06 para pantallas, marca, flujo de sesión y responsive; las capturas reales están físicamente en 09 para evitar duplicados.
7. Redactar calidad con 07, sin sumar peticiones Bruno a tests Vitest ni confundir coverage con porcentaje de requisitos terminados.
8. Explicar CI/Docker desde 08. Sin run remoto comprobado, mostrar diagrama/configuración y ejecución local, nunca una captura verde ficticia.
9. Construir tablas/gráficos desde 10; respetar unidades y NO DISPONIBLE. Seguir el guion de 11 y priorizar 12.

## Reutilización por capítulo

Introducción/caso: RESUMEN_EJECUTIVO y JUSTIFICACION_MICROSERVICIOS. Arquitectura: C4 01–05, Context Map 06 y despliegue 08. Datos: ERD 10 y modelos 11–12. APIs: matriz y OpenAPI. Integración: secuencias 13–17. Calidad: resultados JSON/CSV, JUnit y capturas de reportes reales. Operación: pipeline 18 y health Docker. Conclusiones: riesgos, estado y roadmap.

Cada imagen tiene ID/fecha/fuente en el registro de evidencias; citar ese ID y el archivo primario. Los diagramas son **ilustraciones técnicas derivadas del código**, no screenshots de un sistema desplegado. Las imágenes de UI son capturas reales. No mezclar estas categorías.

## Información que debe conseguir el equipo

Solicitar rúbrica oficial, Dinámica 1 Caso E y Dinámica 2 Caso D con sus Word/PDF, nombres/códigos de integrantes y contribuciones respaldadas, fechas de exposición y un enlace al commit final publicado. No se localizaron esos informes formales en las carpetas revisadas. Validar manualmente las correspondencias con la rúbrica y las decisiones académicas del docente. Confirmar revocación de la credencial histórica con su propietario, sin compartirla. El calendario semanas 9–16 incluido es una propuesta, no evidencia de cronograma oficial.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.

Consultar también [Seguridad del paquete](../01_INFORMES_ANTERIORES/SEGURIDAD_DEL_PAQUETE.md), [builds](../07_PRUEBAS_Y_CALIDAD/BUILD_RESULTS.md) y [validación final](VALIDACION_FINAL.json). El inventario y manifiesto están en la raíz del expediente.
