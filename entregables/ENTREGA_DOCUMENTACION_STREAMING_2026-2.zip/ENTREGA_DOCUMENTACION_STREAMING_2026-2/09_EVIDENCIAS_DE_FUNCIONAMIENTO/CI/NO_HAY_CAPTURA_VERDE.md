# CI remoto pendiente

No se generó una captura verde de GitHub Actions: no hay run remoto aprobado verificado. Ver configuración y consulta de runs en 08. Las vistas de tests locales no son CI remoto.
