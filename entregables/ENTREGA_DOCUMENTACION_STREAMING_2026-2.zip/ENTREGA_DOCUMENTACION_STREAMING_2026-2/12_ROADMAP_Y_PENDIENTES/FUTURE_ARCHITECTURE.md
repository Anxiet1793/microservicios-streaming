# Arquitectura futura

Recommendations podría consumir preferencias explícitas y eventos Playback para generar sugerencias; todavía deben definirse contrato, entrega, idempotencia, privacidad/retención y evaluación del algoritmo. Payments requeriría su propio almacenamiento y un modelo de entitlements, sin reutilizar tablas Users como ledger de pagos. Ninguno es requisito funcional ya realizado.

Un bus de eventos necesita dispatcher Outbox, reintentos, seguimiento de offsets, duplicados y DLQ. No basta con añadir un contenedor broker. Un API Gateway podría concentrar ingreso, TLS/cuotas y routing; el BFF actual seguiría cumpliendo composición para la UI. La observabilidad actual es logging y health; tracing/métricas/alertas y resiliencia bajo carga siguen pendientes.

Estos cambios son propuestas y no aparecen como rutas sólidas de implementación en los diagramas actuales. No se implementan como parte del expediente.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **PLANIFICADO**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
