# Matriz provisional de requisitos y evidencia

**PROVISIONAL: no se localizó una rúbrica oficial verificable del curso.** Las filas corresponden a los requisitos del solicitante, no a criterios o puntajes oficiales. No se inventan ponderaciones ni una nota del trabajo.

| ID | Requisito | Archivo del ZIP / evidencia | Estado | Pendiente |
| --- | --- | --- | --- | --- |
| R01 | Caso de negocio | 02_ARQUITECTURA_DDD/JUSTIFICACION_MICROSERVICIOS.md | IMPLEMENTADO | Confirmar caso y consigna oficial |
| R02 | Modelo de dominio | 02_ARQUITECTURA_DDD/DOMAIN_MODEL.md | IMPLEMENTADO | Contrastar con docente |
| R03 | Bounded Contexts | 02_ARQUITECTURA_DDD/CONTEXT_MAP.md | IMPLEMENTADO | No confundir cinco contextos con cinco servicios |
| R04 | Servicios funcionales | 07_PRUEBAS_Y_CALIDAD/TEST_EXECUTION_RESULTS.md | VERIFICADO MEDIANTE PRUEBA | Corte y alcance |
| R05 | REST y contratos | 05_APIS_Y_CONTRATOS/API_ENDPOINT_MATRIX.md | IMPLEMENTADO / PROBADO SEGÚN SUITE | Revisar contrato y negativos |
| R06 | Reglas de negocio | 02_ARQUITECTURA_DDD/REGLAS_DE_NEGOCIO.md | IMPLEMENTADO / PROBADO SEGÚN SUITE | No declarar prueba exhaustiva |
| R07 | Datos independientes | 04_BASES_DE_DATOS/DATA_OWNERSHIP.md | IMPLEMENTADO | Validación de despliegue productivo pendiente |
| R08 | Pruebas automatizadas | 07_PRUEBAS_Y_CALIDAD/TEST_EXECUTION_RESULTS.md | VERIFICADO MEDIANTE PRUEBA | Campañas ampliadas pendientes |
| R09 | Integración continua | 08_CI_CD_Y_DEVOPS/PIPELINE_STAGES.md | IMPLEMENTADO; REMOTO PENDIENTE | Run GitHub enlazado al commit final |
| R10 | README y reproducción | 08_CI_CD_Y_DEVOPS/REPRODUCIBILITY_GUIDE.md | IMPLEMENTADO | Clon limpio del commit final |
| R11 | Contribuciones del equipo | 10_DATOS_Y_TABLAS_PARA_INFORMES/CONTRIBUCIONES.csv | NO DISPONIBLE | Nombres, roles y evidencia de contribución |
| R12 | Diagramas y exposición | 03_DIAGRAMAS_E_IMAGENES/GUIA_DE_DIAGRAMAS.md | DOCUMENTADO | Revisión docente/ensayo |

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **MATRIZ PROVISIONAL**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
