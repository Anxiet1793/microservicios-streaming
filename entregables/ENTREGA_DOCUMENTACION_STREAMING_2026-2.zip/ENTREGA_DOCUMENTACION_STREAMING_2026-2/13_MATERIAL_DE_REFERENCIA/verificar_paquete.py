"""Verifica el manifiesto del expediente extraído. Solo lectura, Python 3 stdlib."""
import hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/"MANIFIESTO_SHA256.json").read_text(encoding="utf-8"))
errors=[]
for entry in manifest["archivos"]:
    path=root/entry["archivo"]
    if not path.is_file(): errors.append({"archivo":entry["archivo"],"error":"faltante"});continue
    data=path.read_bytes()
    if len(data)!=entry["bytes"] or hashlib.sha256(data).hexdigest()!=entry["sha256"]:
        errors.append({"archivo":entry["archivo"],"error":"contenido diferente"})
actual={p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
expected={x["archivo"] for x in manifest["archivos"]}|{"MANIFIESTO_SHA256.json"}
errors.extend({"archivo":x,"error":"archivo adicional"}for x in sorted(actual-expected))
print(json.dumps({"verificados":len(manifest["archivos"]),"errores":errors},ensure_ascii=False,indent=2))
sys.exit(bool(errors))
