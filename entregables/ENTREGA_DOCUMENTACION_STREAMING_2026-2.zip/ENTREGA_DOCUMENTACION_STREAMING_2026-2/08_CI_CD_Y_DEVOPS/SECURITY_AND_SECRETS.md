# Seguridad del expediente

No se incluyen .env privados, Local.bru, archivos PEM/KEY, sesiones, cookies, JWT válidos, dumps, volúmenes o dependencias. .env.example conserva variables y placeholders. Los contratos contienen ejemplos didácticos y los tests usan valores sintéticos; ninguno debe interpretarse como credencial de una cuenta vigente. El paquete se escanea antes de comprimir y las imágenes se revisan visualmente.

Los README/config originales se copian por allowlist y hash. No se recupera el blob Git que contenía una credencial histórica. Solo se incluye el hallazgo sin su valor y el pendiente de revocación externa. Los reportes crudos de sesión/browser nunca se exportan. La captura de perfil utiliza un usuario sintético creado para QA.

Los ejemplos JSON usan marcadores y datos ficticios, sin hashes de contraseña reales. Revisión por patrones no es garantía matemática de ausencia de secretos; complementa la selección acotada, redacción y revisión visual. La clave privada JWT se queda en Users; los otros servicios solo obtienen JWKS público.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [scripts/security/scan_secrets.py](../13_MATERIAL_DE_REFERENCIA/repositorio/scripts/security/scan_secrets.py)
- [docs/quality/SECURITY_REVIEW.md](../07_PRUEBAS_Y_CALIDAD/Antecedentes/SECURITY_REVIEW.md)
