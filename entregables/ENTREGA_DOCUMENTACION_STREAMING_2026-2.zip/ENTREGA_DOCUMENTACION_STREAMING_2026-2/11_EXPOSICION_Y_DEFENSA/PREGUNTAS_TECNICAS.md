# Preguntas para la defensa

| Pregunta | Respuesta sustentada |
| --- | --- |
| ¿Por qué microservicios? | Por propiedad de datos/invariantes y autonomía de despliegue; hay costo operativo y no se probó superioridad de rendimiento. |
| ¿Por qué MongoDB en Catálogo? | Ficha embebida, importación por lotes y queries documentales con validator/índices; no porque Mongo no tenga esquema. |
| ¿Por qué PostgreSQL en Usuarios? | Unicidad, FK internas y transacciones para identidad/perfil/refresh y cuotas. |
| ¿Por qué no comparten BD? | Mantener dueño del dato y contratos; un ID externo no es una FK entre motores. |
| ¿Por qué Playback independiente? | Byte storage, firmas, sesiones y progreso tienen ciclo/recursos distintos de la ficha. |
| ¿Qué regla demuestra la demo? | Un usuario retoma su propio progreso; un completado deja de aparecer en Continuar viendo. |
| ¿Qué riesgos cubren tests? | Invariantes, permisos, concurrencia, contratos, persistencia, media y recuperación; no todo ataque o carga. |
| ¿Qué prueba aporta CI? | Gates configurados y ejecución local; solo un run remoto ligado al commit probaría GitHub Actions. |
| ¿Outbox significa eventos funcionando? | Se guardan transaccionalmente; falta dispatcher/bus/consumidor, por lo que no hay entrega externa acreditada. |
| ¿Qué falta para final? | Rúbrica/documentos formales, commit/run remoto, riesgos de seguridad, carga/restore y campañas ampliadas. |

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **SÍNTESIS PARA DEFENSA**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
