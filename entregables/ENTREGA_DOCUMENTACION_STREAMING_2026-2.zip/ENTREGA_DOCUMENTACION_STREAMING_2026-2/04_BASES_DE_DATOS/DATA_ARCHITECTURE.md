# Arquitectura de datos

Users normaliza datos relacionales con claves/constraints y transacciones. Catalog embebe la ficha en catalog_titles; separa episodios preparados para evitar un array ilimitado. Playback separa assets, sesiones, proyección de progreso y Outbox, usando una transacción Mongo local para cambios relacionados. MinIO conserva bytes, Mongo solo metadata/referencias. Redis conserva la sesión BFF cifrada, no la identidad maestra.

No existe base de datos compartida ni FK entre servicios. Las relaciones externas son contratos públicos UUID con prefijos. El BFF enriquece referencias desde Catalog para presentar fichas y listas, sin copiar sus metadatos a Users PostgreSQL.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [docker-compose.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/docker-compose.yml)
- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
- [playback-service/src/modules/playback/infrastructure/mongo.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/infrastructure/mongo.ts)
