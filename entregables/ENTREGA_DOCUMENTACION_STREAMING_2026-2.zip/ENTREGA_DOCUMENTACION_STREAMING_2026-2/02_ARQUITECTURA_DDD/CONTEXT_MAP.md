# Mapa de contextos

Users es upstream de identidad y publica JWT/JWKS como lenguaje de integración. Catalog es upstream del descriptor de título reproducible; Playback es downstream y traduce el DTO a `{published, assetId}` mediante CatalogGateway. El BFF es consumidor de los tres contratos y compone sus proyecciones para la UI.

No existe Shared Kernel de entidades entre los servicios en runtime. Hay imports entre proyectos exclusivamente en pruebas de contrato para contrastar productores; no son consultas a bases ajenas. Recomendaciones sería un consumidor futuro de señales de Users y eventos Playback; hoy no hay transporte ni suscripciones. Payments no participa en ninguna autorización actual de reproducción.

Los términos Published Language, upstream/downstream y adapter/anticorruption se emplean como interpretación DDD del código observado. No se afirma un acuerdo organizativo de equipos que no esté documentado.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [playback-service/src/modules/playback/infrastructure/adapters.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/infrastructure/adapters.ts)
- [frontend/src/lib/server/catalog.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/catalog.ts)
- `playback-service/tests/contract/gateways.test.ts` (ruta del repositorio; consultar índice de fuentes)
