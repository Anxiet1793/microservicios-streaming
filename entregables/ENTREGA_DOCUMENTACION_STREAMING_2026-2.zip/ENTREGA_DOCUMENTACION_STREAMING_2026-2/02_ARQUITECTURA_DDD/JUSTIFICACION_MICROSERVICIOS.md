# Justificación y alcance de los microservicios

La separación responde a invariantes y ciclos de datos: Usuarios exige unicidad y consistencia transaccional de credenciales; Catálogo trabaja fichas e importaciones documentales; Reproducción administra archivos, firmas temporales y progreso. Permite cambiar o escalar esos recursos por separado y observar contratos explícitos.

En este MVP no se ha medido una ventaja de escalabilidad frente a un monolito. El valor demostrado es independencia de datos, interfaces y despliegues, con pruebas de integración y fallos parciales. A cambio se requieren varias bases, inicializadores, llaves, caché de JWKS, Redis y recuperación ante red. El número de endpoints no justifica por sí solo un microservicio.

Para un equipo pequeño sin necesidad de despliegues independientes, un monolito modular sería una alternativa pragmática. La elección actual es razonable como ejercicio académico de límites DDD y operación distribuida, sin afirmar que sea la solución universal o más económica.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [docker-compose.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/docker-compose.yml)
- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
