# Errores y ejemplos de API

Users responde `{error:{code,message,requestId}}`; Catalog agrega request-id según su capa HTTP; Playback responde error normalizado sin revelar mensajes internos. Revisar schemas Error/ErrorResponse en cada contrato: no asumir DTO de error idéntico.

Ejemplos JSON didácticos sin tokens reales se incluyen en ejemplos/. Los requests de login/registro requieren una variable de contraseña local generada por el operador. La cookie refresh no debe copiarse al informe. Mi Lista entrega tituloId/addedAt y preferencias tituloId/value; la ficha completa se obtiene de Catalog.

Bruno usa variables temporales (`bru.setVar`) para accessToken, adminAccessToken, tituloId, assetId y sessionId. Los entornos públicos están vacíos de secretos; Local.bru fue excluido. Para ejecutar contra otro equipo, primero preparar su stack y credenciales locales; ver la guía de reproducción. El flujo ordenado está en bruno/demo-plan.json y no coincide con Run Collection por carpetas.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/docs/openapi.yaml](../05_APIS_Y_CONTRATOS/openapi/users.yaml)
- [catalog-service/docs/openapi.yaml](../05_APIS_Y_CONTRATOS/openapi/catalog.yaml)
- [playback-service/docs/openapi.yaml](../05_APIS_Y_CONTRATOS/openapi/playback.yaml)
- [api/bruno/README.md](../05_APIS_Y_CONTRATOS/bruno/README.md)
