# Evidencia de builds

Los siguientes builds host se ejecutaron realmente en el corte previo del dossier EP del mismo día y se conservan como antecedentes, con logs comprobados por SHA-256. No se presentan como comandos repetidos para este paquete. Los 299 archivos de aplicaciones comparados conservan el mismo contenido.

| Proyecto | Comando | Inicio UTC | Duración s | Exit code | Evidencia |
| --- | --- | --- | --- | --- | --- |
| frontend | npm run build | 2026-10-21T05:39:13.395Z | 16.296 | 0 | [log](Evidencia_EP/frontend-build-1.log) |
| users-service | npm run build | 2026-10-21T05:38:24.980Z | 17.404 | 0 | [log](Evidencia_EP/users-service-build-1.log) |
| users-service | npm run build:scripts | 2026-10-21T05:38:42.389Z | 0.469 | 0 | [log](Evidencia_EP/users-service-build-2.log) |
| catalog-service | npm run build | 2026-10-21T05:38:43.100Z | 13.779 | 0 | [log](Evidencia_EP/catalog-service-build-1.log) |
| catalog-service | npm run build:init | 2026-10-21T05:38:56.883Z | 0.462 | 0 | [log](Evidencia_EP/catalog-service-build-2.log) |
| playback-service | npm run build | 2026-10-21T05:38:57.642Z | 14.881 | 0 | [log](Evidencia_EP/playback-service-build-1.log) |
| playback-service | npm run build:scripts | 2026-10-21T05:39:12.528Z | 0.544 | 0 | [log](Evidencia_EP/playback-service-build-2.log) |

El corte principal repitió `CI=true npm run test:e2e` y `docker compose up --build --detach --wait --wait-timeout 300`: ambos construyeron las imágenes Docker actuales y terminaron en 0. Docker puede reutilizar capas; no equivale a un build sin caché. Los registros actuales están en [commands.json](Ejecucion_actual/commands.json), frontend-e2e-1.log y root-stack-1.log. El build actual del frontend también forma parte del runner E2E. No hay run remoto verde acreditado.
