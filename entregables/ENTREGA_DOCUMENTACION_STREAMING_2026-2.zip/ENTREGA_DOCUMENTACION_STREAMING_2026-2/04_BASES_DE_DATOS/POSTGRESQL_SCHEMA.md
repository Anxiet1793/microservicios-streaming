# Esquema PostgreSQL de Users

El esquema migrado contiene seis tablas de aplicación. `profiles.user_id` es PK/FK compartida del bigint interno; el user_id público solo está en users. No hay FK a Catalog. El esquema de control de migraciones de Drizzle no representa otro agregado.

## public.content_preferences

| Campo | Tipo SQL | NULL | PK | Default |
| --- | --- | --- | --- | --- |
| user_id | bigint | NO |  | — |
| title_id | varchar(40) | NO |  | — |
| value | preference_value | NO |  | — |
| created_at | timestamp with time zone | NO |  | now() |
| updated_at | timestamp with time zone | NO |  | now() |

### Índices

```json
{
  "preferences_user_updated_idx": {
    "name": "preferences_user_updated_idx",
    "columns": [
      {
        "expression": "user_id",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      },
      {
        "expression": "updated_at",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      },
      {
        "expression": "title_id",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": false,
    "concurrently": false,
    "method": "btree",
    "with": {}
  }
}
```

### Claves foráneas internas

```json
{
  "content_preferences_user_id_users_id_fk": {
    "name": "content_preferences_user_id_users_id_fk",
    "tableFrom": "content_preferences",
    "tableTo": "users",
    "columnsFrom": [
      "user_id"
    ],
    "columnsTo": [
      "id"
    ],
    "onDelete": "cascade",
    "onUpdate": "no action"
  }
}
```

### PK compuesta

```json
{
  "content_preferences_user_id_title_id_pk": {
    "name": "content_preferences_user_id_title_id_pk",
    "columns": [
      "user_id",
      "title_id"
    ]
  }
}
```

### CHECK

```json
{
  "preferences_title_format": {
    "name": "preferences_title_format",
    "value": "\"content_preferences\".\"title_id\" ~ '^ttl_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'"
  },
  "preferences_dates": {
    "name": "preferences_dates",
    "value": "\"content_preferences\".\"updated_at\" >= \"content_preferences\".\"created_at\""
  }
}
```

## public.profiles

| Campo | Tipo SQL | NULL | PK | Default |
| --- | --- | --- | --- | --- |
| user_id | bigint | NO | SI | — |
| display_name | varchar(100) | NO |  | — |
| avatar_url | varchar(2048) | SI |  | — |
| preferred_language | varchar(5) | NO |  | 'es' |

### Claves foráneas internas

```json
{
  "profiles_user_id_users_id_fk": {
    "name": "profiles_user_id_users_id_fk",
    "tableFrom": "profiles",
    "tableTo": "users",
    "columnsFrom": [
      "user_id"
    ],
    "columnsTo": [
      "id"
    ],
    "onDelete": "cascade",
    "onUpdate": "no action"
  }
}
```

### CHECK

```json
{
  "profile_display_name_nonempty": {
    "name": "profile_display_name_nonempty",
    "value": "length(btrim(\"profiles\".\"display_name\")) > 0"
  },
  "profile_language_format": {
    "name": "profile_language_format",
    "value": "\"profiles\".\"preferred_language\" ~ '^[a-z]{2}(-[A-Z]{2})?$'"
  }
}
```

## public.rate_limit_buckets

| Campo | Tipo SQL | NULL | PK | Default |
| --- | --- | --- | --- | --- |
| key | varchar(100) | NO | SI | — |
| hits | integer | NO |  | — |
| expires_at | timestamp with time zone | NO |  | — |

### Índices

```json
{
  "rate_limit_expiry_idx": {
    "name": "rate_limit_expiry_idx",
    "columns": [
      {
        "expression": "expires_at",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": false,
    "concurrently": false,
    "method": "btree",
    "with": {}
  }
}
```

### CHECK

```json
{
  "rate_limit_positive": {
    "name": "rate_limit_positive",
    "value": "\"rate_limit_buckets\".\"hits\" > 0"
  }
}
```

## public.refresh_tokens

| Campo | Tipo SQL | NULL | PK | Default |
| --- | --- | --- | --- | --- |
| id | uuid | NO | SI | — |
| user_id | bigint | NO |  | — |
| family_id | uuid | NO |  | — |
| token_hash | varchar(64) | NO |  | — |
| expires_at | timestamp with time zone | NO |  | — |
| revoked_at | timestamp with time zone | SI |  | — |
| consumed_at | timestamp with time zone | SI |  | — |
| created_at | timestamp with time zone | NO |  | now() |

### Índices

```json
{
  "refresh_tokens_hash_uq": {
    "name": "refresh_tokens_hash_uq",
    "columns": [
      {
        "expression": "token_hash",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": true,
    "concurrently": false,
    "method": "btree",
    "with": {}
  },
  "refresh_tokens_user_idx": {
    "name": "refresh_tokens_user_idx",
    "columns": [
      {
        "expression": "user_id",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": false,
    "concurrently": false,
    "method": "btree",
    "with": {}
  },
  "refresh_tokens_family_idx": {
    "name": "refresh_tokens_family_idx",
    "columns": [
      {
        "expression": "family_id",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": false,
    "concurrently": false,
    "method": "btree",
    "with": {}
  },
  "refresh_tokens_expiry_idx": {
    "name": "refresh_tokens_expiry_idx",
    "columns": [
      {
        "expression": "expires_at",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": false,
    "concurrently": false,
    "method": "btree",
    "with": {}
  }
}
```

### Claves foráneas internas

```json
{
  "refresh_tokens_user_id_users_id_fk": {
    "name": "refresh_tokens_user_id_users_id_fk",
    "tableFrom": "refresh_tokens",
    "tableTo": "users",
    "columnsFrom": [
      "user_id"
    ],
    "columnsTo": [
      "id"
    ],
    "onDelete": "cascade",
    "onUpdate": "no action"
  }
}
```

### CHECK

```json
{
  "refresh_hash_format": {
    "name": "refresh_hash_format",
    "value": "\"refresh_tokens\".\"token_hash\" ~ '^[0-9a-f]{64}$'"
  },
  "refresh_dates": {
    "name": "refresh_dates",
    "value": "\"refresh_tokens\".\"expires_at\" > \"refresh_tokens\".\"created_at\""
  }
}
```

## public.users

| Campo | Tipo SQL | NULL | PK | Default |
| --- | --- | --- | --- | --- |
| id | bigserial | NO | SI | — |
| user_id | varchar(40) | NO |  | — |
| email | varchar(254) | NO |  | — |
| password_hash | text | NO |  | — |
| status | user_status | NO |  | 'ACTIVE' |
| role | user_role | NO |  | 'USER' |
| auth_version | integer | NO |  | 1 |
| created_at | timestamp with time zone | NO |  | now() |
| updated_at | timestamp with time zone | NO |  | now() |

### Índices

```json
{
  "users_user_id_uq": {
    "name": "users_user_id_uq",
    "columns": [
      {
        "expression": "user_id",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": true,
    "concurrently": false,
    "method": "btree",
    "with": {}
  },
  "users_email_uq": {
    "name": "users_email_uq",
    "columns": [
      {
        "expression": "email",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": true,
    "concurrently": false,
    "method": "btree",
    "with": {}
  }
}
```

### CHECK

```json
{
  "users_email_normalized": {
    "name": "users_email_normalized",
    "value": "\"users\".\"email\" = lower(btrim(\"users\".\"email\"))"
  },
  "users_id_format": {
    "name": "users_id_format",
    "value": "\"users\".\"user_id\" ~ '^usr_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'"
  },
  "users_auth_version_positive": {
    "name": "users_auth_version_positive",
    "value": "\"users\".\"auth_version\" > 0"
  },
  "users_dates": {
    "name": "users_dates",
    "value": "\"users\".\"updated_at\" >= \"users\".\"created_at\""
  }
}
```

## public.watchlist_items

| Campo | Tipo SQL | NULL | PK | Default |
| --- | --- | --- | --- | --- |
| user_id | bigint | NO |  | — |
| title_id | varchar(40) | NO |  | — |
| created_at | timestamp with time zone | NO |  | now() |

### Índices

```json
{
  "watchlist_user_created_idx": {
    "name": "watchlist_user_created_idx",
    "columns": [
      {
        "expression": "user_id",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      },
      {
        "expression": "created_at",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      },
      {
        "expression": "title_id",
        "isExpression": false,
        "asc": true,
        "nulls": "last"
      }
    ],
    "isUnique": false,
    "concurrently": false,
    "method": "btree",
    "with": {}
  }
}
```

### Claves foráneas internas

```json
{
  "watchlist_items_user_id_users_id_fk": {
    "name": "watchlist_items_user_id_users_id_fk",
    "tableFrom": "watchlist_items",
    "tableTo": "users",
    "columnsFrom": [
      "user_id"
    ],
    "columnsTo": [
      "id"
    ],
    "onDelete": "cascade",
    "onUpdate": "no action"
  }
}
```

### PK compuesta

```json
{
  "watchlist_items_user_id_title_id_pk": {
    "name": "watchlist_items_user_id_title_id_pk",
    "columns": [
      "user_id",
      "title_id"
    ]
  }
}
```

### CHECK

```json
{
  "watchlist_title_format": {
    "name": "watchlist_title_format",
    "value": "\"watchlist_items\".\"title_id\" ~ '^ttl_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'"
  }
}
```

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **ESQUEMA DE MIGRACIÓN IMPLEMENTADO; INTEGRACIÓN EN POSTGRESQL PROBADA**.

- [users-service/src/modules/users/infrastructure/persistence/schema.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/infrastructure/persistence/schema.ts)
- [users-service/drizzle/0000_busy_carlie_cooper.sql](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/drizzle/0000_busy_carlie_cooper.sql)
