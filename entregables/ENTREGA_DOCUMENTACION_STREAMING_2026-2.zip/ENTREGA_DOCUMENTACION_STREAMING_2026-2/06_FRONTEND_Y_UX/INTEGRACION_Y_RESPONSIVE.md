# Integración y responsive

El frontend no llama Mongo/PostgreSQL/MinIO con credenciales desde JavaScript. Consume BFF same-origin con header propio para mutaciones; los tokens entre APIs quedan en servidor. El recurso multimedia se obtiene directamente por URL temporal. Sesión expirada puede intentar refresh coordinado; un fallo definitivo retorna al login. Errores del catálogo y reproducción tienen estados controlados y recuperación.

Las capturas se toman sobre el stack local y datos sintéticos. No se insertan imágenes generadas de pantallas. Los reportes de calidad incluyen tests de rollback optimista, loading/error, permisos, pausa/reanudación y responsive. No se ha hecho una campaña completa de accesibilidad ni pruebas de todos los codecs/navegadores.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [frontend/src/lib/server/session.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/session.ts)
- [frontend/src/lib/server/http.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/http.ts)
- [frontend/src/styles/tokens.css](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/styles/tokens.css)
