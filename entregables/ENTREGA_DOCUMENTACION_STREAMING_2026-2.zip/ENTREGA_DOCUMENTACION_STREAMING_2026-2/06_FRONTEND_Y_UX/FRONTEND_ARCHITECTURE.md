# Arquitectura del frontend

Next App Router organiza grupos public/viewer/admin/player. Las páginas SSR obtienen sesión/datos; componentes client realizan interacción mediante `/api/bff`. El navegador recibe una cookie opaca HttpOnly, no los JWT de microservicios. Redis conserva tokens cifrados AES-GCM y coordina refresh mediante locking/CAS.

TanStack Query administra estado remoto/invalidación; React Hook Form y Zod validan formularios. La cola PlaybackQueue ordena progreso/pausa/completar y evita que respuestas atrasadas reviertan posición. El player renueva URLs sin perder estado pausado. La navegación filtra destinos de retorno inseguros y guards comprueban rol ADMIN.

El BFF traduce contratos heterogéneos y compone referencias con Catalog; no existe un frontend de Recommendations. Componentes vacíos/errores visibles no equivalen a servicio caído permanente: los tests de recuperación lo distinguen.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [frontend/src/app/api/bff/[...path]/route.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/app/api/bff/[...path]/route.ts)
- [frontend/src/lib/server/session.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/session.ts)
- [frontend/src/lib/server/catalog.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/catalog.ts)
- [frontend/src/proxy.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/proxy.ts)
