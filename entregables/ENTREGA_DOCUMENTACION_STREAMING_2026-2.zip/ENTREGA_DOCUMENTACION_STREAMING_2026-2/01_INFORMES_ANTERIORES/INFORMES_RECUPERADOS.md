# Informes y versiones recuperados

Se recuperó ARQUITECTURA_DATOS_Y_APIS.md del repositorio como documento técnico, el plan NÉVARO v0.9 fechado 17/10/2026 y la documentación original de los servicios/frontend/calidad. No se acreditó autoría académica individual ni aprobación docente de esos textos.

No se localizaron los Word/PDF de Dinámica Grupal 1 Caso E, Dinámica Grupal 2 Caso D ni una rúbrica oficial de Arquitectura de Microservicios. Se revisaron el repositorio y nombres/candidatos pertinentes de Escritorio, Documentos, Descargas y adjuntos locales. Los Word genéricos examinados correspondían a otro curso y fueron excluidos. No se incluyeron CV, contratos ni documentación personal. No se afirma que los documentos faltantes no existan en el campus virtual o cuentas no consultadas.

El plan fechado 17/10 es histórico; la síntesis vigente de este paquete y las ejecuciones del 21/10 prevalecen para describir implementación. Algunos README originales de fases iniciales aún nombran Playback como futuro; se conservan para trazabilidad, no como estado actual.

Originales sin modificar y hashes: ORIGINAL_FILES.json. Contenido idéntico se conserva una sola vez y sus alias aparecen en DUPLICADOS.json. Versiones con contenido diferente permanecen separadas.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **RECUPERACIÓN LOCAL; INFORMES ACADÉMICOS FORMALES PENDIENTES**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
