# Comparación de alternativas

| Criterio | Monolito | Monolito modular | Microservicios actuales |
| --- | --- | --- | --- |
| Despliegue | Unidad única | Unidad única con módulos | Frontend y APIs por separado |
| Datos | Frecuentemente compartidos | Propiedad lógica por módulo | Almacenes por servicio |
| Consistencia | Transacción local sencilla | Transacciones locales controlables | Transacciones locales; referencias externas |
| Cambios | Mayor acoplamiento si no hay límites | Límites internos comprobables | Contratos y red; coordinación de cambios |
| Operación | Menor costo inicial | Costo intermedio | Más recursos, secretos, health y observabilidad |
| Fallos | Proceso compartido | Proceso compartido | Fallos parciales de red/dependencias |
| Cuándo usar | Dominio pequeño/equipo inicial | Dominio con módulos y equipo pequeño | Autonomía de despliegue/datos justificada |

Esta comparación es análisis de diseño, no un benchmark ejecutado. El proyecto no contiene implementaciones paralelas de las tres alternativas para compararlas empíricamente.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **ANÁLISIS ARQUITECTÓNICO**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
