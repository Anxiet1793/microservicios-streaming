# Etapas del pipeline

| Etapa | Configuración observada |
| --- | --- |
| checkout | actions/checkout con SHA y persist-credentials:false |
| install | Node 24.21.0, npm 12.2.0, npm ci; productores de contrato para Playback |
| static | Prettier, scanner sin valores, audit separado, ESLint y tsc |
| test | Vitest coverage y contenedores de integración propios |
| contract | docs:check backend y validación colección Bruno |
| build | Next production + herramientas migración/init |
| e2e | Playwright Chromium y stack completo exclusivo |
| smoke/demo | Compose raíz, smoke, Bruno con limpieza de su media |
| artifacts | Coverage/JUnit/HTML/logs saneados, always para diagnósticos |
| cleanup | Solo recursos/volúmenes desechables del runner de CI |

Cada comando obligatorio debe devolver 0; no hay `|| true` para ocultar fallos. Las excepciones de limpieza de imágenes no equivalen a ignorar un fallo de tests. Ver resultados locales y consulta remota: configuración no prueba ejecución exitosa en GitHub.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [.github/workflows/ci.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/.github/workflows/ci.yml)
- [.github/workflows/quality.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/.github/workflows/quality.yml)
