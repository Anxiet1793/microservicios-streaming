# Modelo MongoDB de Catalog

Modelos extraídos de los validadores e índices actuales. No son un dump de datos. En Playback el validador no declara tipos de todos los campos: se distingue el tipo del modelo TypeScript de la garantía BSON. Catalog usa objetos cerrados/Int32; Playback permite campos no enumerados en propiedades según el validador actual.

## catalog_titles

| Campo BSON | Tipo validado | Requerido | Restricciones |
| --- | --- | --- | --- |
| _id | objectId | SI | {} |
| schemaVersion | int | SI | {"enum": [1]} |
| publicationStatusId | int | SI | {"enum": [1, 2, 3]} |
| createdAt | date | SI | {} |
| updatedAt | date | SI | {} |
| version | int | SI | {"minimum": 1, "maximum": 2147483647} |
| tituloId | string | SI | {"pattern": "^ttl_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"} |
| importKey | string | SI | {"minLength": 1, "maxLength": 160, "pattern": "^\\S(?:[\\s\\S]*\\S)?$"} |
| importFingerprint | string | SI | {"pattern": "^[a-f0-9]{64}$"} |
| typeId | int | SI | {"enum": [1, 2]} |
| ficha | object | SI | {"additionalProperties": false, "required": ["title", "synopsis", "releaseYear", "genres", "languages", "cast"]} |
| ficha.title | string | SI | {"minLength": 1, "maxLength": 300, "pattern": "\\S"} |
| ficha.synopsis | string | SI | {"minLength": 1, "maxLength": 10000, "pattern": "\\S"} |
| ficha.releaseYear | int | SI | {"minimum": 1888, "maximum": 9999} |
| ficha.durationMinutes | int | NO | {"minimum": 1, "maximum": 100000} |
| ficha.genres | array | SI | {"minItems": 1, "maxItems": 20, "uniqueItems": true} |
| ficha.languages | array | SI | {"minItems": 1, "maxItems": 20, "uniqueItems": true} |
| ficha.originalTitle | string | NO | {"minLength": 1, "maxLength": 300, "pattern": "\\S"} |
| ficha.ageRatingId | int | NO | {"enum": [1, 2, 3, 4, 5, 6]} |
| ficha.posterUrl | string | NO | {"minLength": 1, "maxLength": 2048, "pattern": "^https?://"} |
| ficha.backdropUrl | string | NO | {"minLength": 1, "maxLength": 2048, "pattern": "^https?://"} |
| ficha.director | string | NO | {"minLength": 1, "maxLength": 300, "pattern": "\\S"} |
| ficha.cast | array | SI | {"maxItems": 100} |
| playbackReference | oneOf | SI | {"oneOf": [{"bsonType": "object", "additionalProperties": false, "required": ["providerId", "assetId", "manifestKey"], "properties": {"providerId": {"bsonType": "int", "enum": [1]}, "assetId": {"bsonType": "string", "minLength": 1, "maxLength": 256, "pattern": "\\S"}, "manifestKey": {"bsonType": "string", "minLength": 1, "maxLength": 2048, "pattern": "\\S"}}}, {"bsonType": "null"}]} |

### Índices

```json
[
  {
    "name": "uq_catalog_titles_titulo_id",
    "key": {
      "tituloId": 1
    },
    "unique": true
  },
  {
    "name": "uq_catalog_titles_import_key",
    "key": {
      "importKey": 1
    },
    "unique": true
  },
  {
    "name": "ix_catalog_titles_updated",
    "key": {
      "updatedAt": -1,
      "tituloId": 1
    }
  },
  {
    "name": "ix_catalog_titles_status_type_updated",
    "key": {
      "publicationStatusId": 1,
      "typeId": 1,
      "updatedAt": -1,
      "tituloId": 1
    }
  },
  {
    "name": "ix_catalog_titles_year",
    "key": {
      "ficha.releaseYear": 1
    }
  },
  {
    "name": "ix_catalog_titles_genre",
    "key": {
      "ficha.genres": 1
    }
  },
  {
    "name": "tx_catalog_titles_title",
    "key": {
      "ficha.title": "text",
      "ficha.originalTitle": "text"
    },
    "default_language": "none"
  }
]
```

## catalog_episodes

| Campo BSON | Tipo validado | Requerido | Restricciones |
| --- | --- | --- | --- |
| _id | objectId | SI | {} |
| schemaVersion | int | SI | {"enum": [1]} |
| publicationStatusId | int | SI | {"enum": [1, 2, 3]} |
| createdAt | date | SI | {} |
| updatedAt | date | SI | {} |
| version | int | SI | {"minimum": 1, "maximum": 2147483647} |
| episodeId | string | SI | {"pattern": "^ep_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"} |
| seriesId | string | SI | {"pattern": "^ttl_[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"} |
| seasonNumber | int | SI | {"minimum": 1, "maximum": 2147483647} |
| episodeNumber | int | SI | {"minimum": 1, "maximum": 2147483647} |
| ficha | object | SI | {"additionalProperties": false, "required": ["title", "synopsis", "durationMinutes"]} |
| ficha.title | string | SI | {"minLength": 1, "maxLength": 300, "pattern": "\\S"} |
| ficha.synopsis | string | SI | {"minLength": 1, "maxLength": 10000, "pattern": "\\S"} |
| ficha.durationMinutes | int | SI | {"minimum": 1, "maximum": 100000} |
| playbackReference | object | SI | {"additionalProperties": false, "required": ["providerId", "assetId", "manifestKey"]} |
| playbackReference.providerId | int | SI | {"enum": [1]} |
| playbackReference.assetId | string | SI | {"minLength": 1, "maxLength": 256, "pattern": "\\S"} |
| playbackReference.manifestKey | string | SI | {"minLength": 1, "maxLength": 2048, "pattern": "\\S"} |

### Índices

```json
[
  {
    "name": "uq_catalog_episodes_episode_id",
    "key": {
      "episodeId": 1
    },
    "unique": true
  },
  {
    "name": "uq_catalog_episodes_position",
    "key": {
      "seriesId": 1,
      "seasonNumber": 1,
      "episodeNumber": 1
    },
    "unique": true
  }
]
```

catalog_episodes está preparada con episodeId único y posición única por serie/temporada/episodio; no tiene API implementada. La película requiere durationMinutes y playbackReference; la serie no admite ninguno de esos campos propios. El JSON completo conserva oneOf y límites que la tabla de campos resume.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [catalog-service/src/modules/catalog/infrastructure/persistence/mongodb/validators/catalog-validators.ts](../13_MATERIAL_DE_REFERENCIA/fuentes/5803ea9d93_catalog-validators.ts)
- [catalog-service/src/modules/catalog/infrastructure/persistence/mongodb/indexes/catalog-indexes.ts](../13_MATERIAL_DE_REFERENCIA/fuentes/6a98b837fc_catalog-indexes.ts)
