# Ejemplos sintéticos

Estos JSON/EJSON fueron construidos para explicar el modelo, no extraídos de usuarios o bases productivas. IDs, email, fechas y ficha son ficticios. Los .ejson usan Extended JSON de MongoDB; un parser JSON convencional no convierte automáticamente $date/$oid/$numberInt a BSON. El tamaño/duración del asset ilustran el fixture sintético existente y no un registro exportado. No incluyen password_hash, refresh ni secretos. Los modelos completos de constraints/indices están en ../modelos.
