# Propiedad de los datos

| Almacén | Propietario | Contenido |
| --- | --- | --- |
| Users PostgreSQL | Users | users, profiles, refresh_tokens, watchlist_items, content_preferences, rate_limit_buckets |
| Catalog MongoDB | Catalog | catalog_titles, catalog_episodes preparada |
| Playback MongoDB | Playback | media_assets, playback_sessions, playback_progress, outbox_events, rate_limit_buckets |
| MinIO bucket privado | Playback | Bytes MP4; objectKey generado por servidor |
| Redis | Frontend/BFF | Sesión opaca, cifrado de tokens, locking/CAS |

Acceder directamente a la base de otro servicio violaría este contrato. La lectura técnica de esquemas durante QA no equivale a una dependencia de la aplicación.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [docker-compose.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/docker-compose.yml)
