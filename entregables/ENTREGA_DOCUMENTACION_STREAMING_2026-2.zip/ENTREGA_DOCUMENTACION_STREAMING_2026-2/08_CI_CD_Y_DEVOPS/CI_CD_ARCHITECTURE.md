# Arquitectura de CI y despliegue

GitHub Actions está configurado mediante ci.yml y reusable quality.yml: cuatro jobs de calidad y un E2E dependiente de los cuatro. PR/push relevante y workflow_dispatch disparan checks, con concurrency por PR/ref y permiso contents:read. Cache npm se basa en lockfiles; no cachea .next como resultado de build.

Los jobs instalan con npm ci, ejecutan formato/secret scan/audit/lint/tipos, coverage con integraciones, OpenAPI y build, luego publican artifacts. E2E instala Chromium, prueba stack aislado, levanta Compose raíz y ejecuta smoke/demo Bruno; artifacts se sanean antes de compartir.

No hay despliegue continuo a producción comprobado. Docker Compose local y sus scripts no son evidencia de CD productivo ni de un cluster HA. La consulta de GitHub incluida distingue configuración de ejecución remota. No se genera un badge o pantalla verde inventada.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [.github/workflows/ci.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/.github/workflows/ci.yml)
- [.github/workflows/quality.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/.github/workflows/quality.yml)
