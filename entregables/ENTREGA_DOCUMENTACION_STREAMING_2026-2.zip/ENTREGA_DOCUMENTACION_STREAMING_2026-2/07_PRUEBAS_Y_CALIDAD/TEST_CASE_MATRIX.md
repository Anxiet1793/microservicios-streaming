# Matriz de casos ejecutados

Cada fila corresponde a un caso real del reporte Vitest del corte principal. Los nombres repetidos pueden ser casos parametrizados; no se deduplican por nombre, pues son ejecuciones distintas.

| Proyecto | Tipo | Archivo | Caso | Resultado |
| --- | --- | --- | --- | --- |
| frontend | unit | frontend/tests/unit/player.test.ts | ordered playback writes coalesces pending positions without removing intentional backward seeks | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | ordered playback writes finishes progress before pause and completion | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | ordered playback writes does not permanently block the queue after a network error | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | ordered playback writes stops future writes when superseded | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return https://evil.example | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return //evil.example | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return /\evil | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return /api/bff/admin | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries rejects unsafe return /login?next=https://evil.example | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries preserves local title return | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries formats NaN safely | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries formats -3 safely | passed |
| frontend | unit | frontend/tests/unit/player.test.ts | navigation and display boundaries formats 65.8 safely | passed |
| frontend | unit | frontend/tests/unit/query.test.ts | URL search boundary normalizes hostile or out-of-contract filters before calling Catalog | passed |
| frontend | unit | frontend/tests/unit/query.test.ts | URL search boundary keeps Spanish search and normalizes valid numeric values | passed |
| frontend | unit | frontend/tests/unit/query.test.ts | URL search boundary limits query length without breaking Unicode characters | passed |
| frontend | component | frontend/tests/component/actions.test.tsx | personal state under failure distinguishes a wrong current password from an expired session | passed |
| frontend | component | frontend/tests/component/actions.test.tsx | personal state under failure rolls back an optimistic watchlist toggle after a rejected write | passed |
| frontend | component | frontend/tests/component/actions.test.tsx | personal state under failure keeps an incomplete paginated state unknown rather than enabling neutral actions | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | upload route checks USER before rendering the form | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | upload route checks ADMIN before rendering the form | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | streams MP4, exposes upload progress and confirms asset metadata | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | reports uncertain upload after onerror without automatically retrying | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | reports uncertain upload after ontimeout without automatically retrying | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | reports uncertain upload after onabort without automatically retrying | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | shows a controlled API upload error | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | rejects a non MP4 before starting a network transfer | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | retains a stable import key after a rejected ficha and publishes without uploading twice | passed |
| frontend | component | frontend/tests/component/admin.test.tsx | editor preserves noneditable catalog metadata while clearing blank artwork URLs | passed |
| frontend | component | frontend/tests/component/auth.test.tsx | LoginForm submits once, shows loading and returns to a safe destination | passed |
| frontend | component | frontend/tests/component/auth.test.tsx | RegisterForm creates an account and never redirects before login | passed |
| frontend | component | frontend/tests/component/auth.test.tsx | validates registration and email before calling the API | passed |
| frontend | component | frontend/tests/component/auth.test.tsx | shows generic authentication errors and allows another attempt | passed |
| frontend | component | frontend/tests/component/auth.test.tsx | honors Retry-After instead of silently retrying credentials | passed |
| frontend | component | frontend/tests/component/auth.test.tsx | does not dispatch a session-expiry event for a rejected login | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | MediaCard uses catalog IDs, metadata and an image fallback on load failure | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | MediaRow/Section renders its cards and collection link | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | detail offers playback only for a published movie with an asset | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | debounces search, preserves filters, resets pagination and cancels on unmount | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | renders search/filter values, preserves them in pagination and shows empty results | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | Continue Watching exposes a percentage and resumes the same title | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | watchlist shows a controlled error and retries | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | continue-watching shows a controlled error and retries | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | preferences shows a controlled error and retries | passed |
| frontend | component | frontend/tests/component/catalog.test.tsx | history shows a controlled error and retries | passed |
| frontend | component | frontend/tests/component/library.test.tsx | loads the full page after visiting a four-item Home preview | passed |
| frontend | component | frontend/tests/component/personal.test.tsx | adds and removes a watchlist reference using optimistic state | passed |
| frontend | component | frontend/tests/component/personal.test.tsx | restores an existing item when optimistic removal fails | passed |
| frontend | component | frontend/tests/component/personal.test.tsx | sets LIKE and removes it when pressed again | passed |
| frontend | component | frontend/tests/component/personal.test.tsx | sets DISLIKE and removes it when pressed again | passed |
| frontend | component | frontend/tests/component/personal.test.tsx | changes LIKE to DISLIKE without deleting first and rolls back a failed change | passed |
| frontend | component | frontend/tests/component/player.test.tsx | creates a single session, exposes loading and restores initial currentTime | passed |
| frontend | component | frontend/tests/component/player.test.tsx | plays, persists a seek, pauses with position and resumes with a new URL | passed |
| frontend | component | frontend/tests/component/player.test.tsx | automatically saves playing progress every ten seconds and stops timers on unmount | passed |
| frontend | component | frontend/tests/component/player.test.tsx | completes once and stops progress after completion | passed |
| frontend | component | frontend/tests/component/player.test.tsx | renews an expiring URL while preserving paused position | passed |
| frontend | component | frontend/tests/component/player.test.tsx | offers recovery after a media error and renews without creating another session | passed |
| frontend | component | frontend/tests/component/player.test.tsx | reports playback service failure and allows opening another session | passed |
| frontend | component | frontend/tests/component/session.test.tsx | logout clears private cached data, revoked=true | passed |
| frontend | component | frontend/tests/component/session.test.tsx | logout clears private cached data, revoked=false | passed |
| frontend | component | frontend/tests/component/session.test.tsx | failed logout retains session, reports failure and enables retry | passed |
| frontend | component | frontend/tests/component/session.test.tsx | profile presents administration only to USER when appropriate | passed |
| frontend | component | frontend/tests/component/session.test.tsx | profile presents administration only to ADMIN when appropriate | passed |
| frontend | component | frontend/tests/component/session.test.tsx | profile patches editable fields, exposes loading and reports success | passed |
| frontend | component | frontend/tests/component/session.test.tsx | password change clears cache and returns to login only after confirmation | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects invalid registration (email) without writing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects invalid registration (password) without writing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects invalid registration (role injection) without writing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects invalid registration (empty profile) without writing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled registers with 201 without password/hash or a caller-selected role | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled login issues valid claims but exposes refresh only via HttpOnly cookie | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled returns generic login error for wrong-password | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled returns generic login error for missing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled returns generic login error for inactive | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects every personal route without identity | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled accepts a genuine USER identity without allowing privilege injection | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled accepts a genuine ADMIN identity without allowing privilege injection | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects a validly signed token whose user no longer exists | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled does not reveal protected profile fields or accept them in PATCH | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled lists, adds and idempotently removes references without catalog metadata | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled accepts LIKE and deletes a preference | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled accepts DISLIKE and deletes a preference | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled rejects malformed identifiers, repeated pagination and protected preference fields | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled refresh requires CSRF proof, rotates cookie and rejects a reused family | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled logout clears the cookie and change-password passes through current-credential checks | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled returns a bounded 429 with Retry-After and never invokes credential hashing | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled health checks dependencies and JWKS exposes no private key material | passed |
| users-service | api | users-service/tests/api/routes.test.ts | Actual Users Route Handlers, crypto real, repository ports controlled responds safely to malformed bodies, foreign origin and unsupported methods | passed |
| users-service | contract | users-service/tests/contract/public.test.ts | keeps public profile and auth DTOs compatible without leaking credential/internal state | passed |
| users-service | contract | users-service/tests/contract/public.test.ts | publishes stable cross-service RS256 identity, role, audience, TTL and key selection | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios repite migración y conserva seis tablas sin metadata de Catálogo | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios registro crea usuario y perfil, con hash y rol USER | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios hace rollback de usuario si falla la inserción del perfil | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios impide emails duplicados incluso con registros concurrentes | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios login devuelve JWT y guarda solo hash de refresh | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios login incorrecto, ausente o inactivo devuelve el mismo error | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios rota sin prolongar caducidad absoluta y revoca familia al reutilizar | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios dos refresh simultáneos no dejan una familia utilizable tras detectar replay | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios logout con token anterior revoca también la rotación reciente | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios rechaza refresh vencido | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios actualiza perfil parcialmente y limpia avatar sin cambiar email/rol | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios cambio de password revoca sesiones y versión JWT local | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios creación de sesión rechaza credenciales obsoletas tras cambio de password | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios Mi Lista impide duplicados, pagina, elimina y aísla usuarios | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios LIKE→DISLIKE conserva createdAt y PUT idéntico no modifica updatedAt | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios rate limit comparte contador atómico entre instancias | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios revoca únicamente la familia del logout y conserva otra sesión independiente | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios aísla LIKE/DISLIKE y su eliminación por usuario incluso para el mismo tituloId | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios mantiene UNIQUE de Mi Lista bajo inserciones simultáneas | passed |
| users-service | integration | users-service/tests/integration/postgres.test.ts | PostgreSQL real, migraciones, seguridad y repositorios expira ventanas de cuotas sin permitir que contadores previos bloqueen permanentemente | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados registro hashea contraseña y no retorna el hash | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados propaga email duplicado sin generar otra sesión | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados login guarda solo digest de refresh y retorna JWT | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados login ausente ejecuta verificación dummy y devuelve error genérico | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados rechaza contraseña incorrecta, usuario inactivo y carrera con cambio de password | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados rota refresh y rechaza reutilización | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados logout revoca por hash y es idempotente sin cookie | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados actualiza perfil solo del usuario autenticado | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados cambio de contraseña requiere la actual y compara hash esperado | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados watchlist agrega, lista, elimina y propaga duplicados | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados almacena LIKE y admite eliminar preferencia | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados almacena DISLIKE y admite eliminar preferencia | passed |
| users-service | unit | users-service/tests/unit/application.test.ts | Casos de uso aislados rechaza versiones y roles falsos, usuarios inactivos y paginación excesiva | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"authVersion":0} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"authVersion":1.1} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"status":"DELETED"} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"role":"ROOT"} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"userId":"internal-id"} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"passwordHash":""} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"createdAt":null} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects invalid restored aggregate {"updatedAt":"1970-01-01T00:00:00.000Z"} | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | validates password boundaries using Unicode code points without trimming | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | rejects unsafe avatar/locale values while allowing regional language tags | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | bounds pagination by the maximum offset, not just page size | passed |
| users-service | unit | users-service/tests/unit/boundaries.test.ts | requires HTTPS in production and rejects malformed or credential-bearing origins | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects normaliza email y registra USER ACTIVE con identidad independiente | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza email inválido  | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza email inválido bad | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza email inválido a@ | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza email inválido a b@example.com | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza contraseña inválida | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza contraseña inválida | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza contraseña inválida | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects no modifica contraseñas y admite frases largas | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects aplica cambios parciales inmutables y permite quitar avatar | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects rechaza campos protegidos, perfil vacío y URLs inseguras | passed |
| users-service | unit | users-service/tests/unit/domain.test.ts | Usuario y value objects acepta exclusivamente el TituloId público de Catálogo | passed |
| users-service | unit | users-service/tests/unit/security.test.ts | Seguridad Argon2id usa sal aleatoria y verifica sin exponer contraseña | passed |
| users-service | unit | users-service/tests/unit/security.test.ts | Seguridad refresh aleatorio almacenable como SHA-256 y rechaza tokens malformados | passed |
| users-service | unit | users-service/tests/unit/security.test.ts | Seguridad JWT RS256 se verifica con JWKS sin clave privada ni acceso a base | passed |
| users-service | unit | users-service/tests/unit/security.test.ts | Seguridad protege cookie y exige origen o cabecera CSRF para refresh/logout | passed |
| users-service | unit | users-service/tests/unit/security.test.ts | Seguridad no permite privilegios aportados en registro o perfil | passed |
| users-service | unit | users-service/tests/unit/security.test.ts | Seguridad limita bytes reales y oculta errores y logs sensibles | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS denies anonymous and USER before parsing or opening MongoDB | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS denies anonymous and USER before parsing or opening MongoDB | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS denies anonymous and USER before parsing or opening MongoDB | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS accepts ADMIN using the public key only and caches the trusted JWKS | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"role":["ADMIN"]} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"iat":"invalid"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"iat":1792617758} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"iat":1792614098} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"role":"ROOT"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"role":null} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"jti":123} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"jti":""} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"sub":"internal-id"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"userId":"another-user"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"iss":"evil"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"aud":"evil"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"exp":1} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects malformed/incompatible claims {"nbf":1792621298} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects invalid protected headers {"typ":"NOT-JWT"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects invalid protected headers {"kid":"other"} | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS rejects bad signatures, unsigned tokens, HS256 and oversized authorization | passed |
| catalog-service | api | catalog-service/tests/api/authorization.test.ts | Catalog authorization with real RSA signatures and HTTP JWKS fails closed on JWKS outage and refuses credentialed or non-HTTP key URLs | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary imports a mixed batch with stable original indices and partial HTTP 207 | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary accepts the configured maximum exactly and rejects maximum+1 without writes | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary does not persist an entirely invalid batch | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary maps duplicate retries, conflicting import keys and uncertain outcomes truthfully | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary passes filters/search/page through normalization and keeps list metadata minimal | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary represents an empty catalog without fictional pages or data | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?limit=101 before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?page=1&page=2 before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?status=99 before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?genre[$ne]=1 before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects invalid list input ?q=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx before persistence | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary returns a withdrawn title directly, while consumers must decide visibility | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary distinguishes invalid identity from a valid identity that does not exist | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary updates only editorial fields and rejects protected fields without persisting | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary publishes, withdraws and repeats status idempotently without forbidden transitions | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary health and queries fail safely when persistence is unavailable | passed |
| catalog-service | api | catalog-service/tests/api/routes.test.ts | Actual Catalog HTTP routes with controlled repository boundary rejects malformed JSON and provides method metadata without leaking internals | passed |
| catalog-service | contract | catalog-service/tests/contract/public.test.ts | preserves the public playback-facing reference and publication contract for all statuses | passed |
| catalog-service | contract | catalog-service/tests/contract/public.test.ts | keeps the declared status IDs synchronized with the producer's domain | passed |
| catalog-service | contract | catalog-service/tests/contract/public.test.ts | serializes optional editorial data without losing numeric/name equivalences | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas busca por TituloId y entrega equivalencias sin metadatos internos | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas distingue inexistencia de identidad inválida | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas filtra y pagina sin exponer ficha completa ni referencia técnica | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas importa válidos en una única llamada preservando índices originales | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas no escribe lotes vacíos, excesivos ni enteramente inválidos | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas distingue duplicados, conflictos y resultados indeterminados | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas no inventa éxito si el repositorio omite resultados | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas actualiza la ficha, omite no-op y propaga conflictos concurrentes | passed |
| catalog-service | unit | catalog-service/tests/unit/application.test.ts | Casos de uso sin conexiones externas delega transiciones en dominio antes de escribir | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | requires movie duration and media reference independently | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"version":0} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"version":1.5} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"version":2147483648} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"updatedAt":"1970-01-01T00:00:00.000Z"} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects corrupt persisted catalog state {"createdAt":null} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | prevents version overflow and invalid/regressive modification dates | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"providerId":999} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"assetId":" "} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"manifestKey":""} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"assetId":"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | rejects incompatible playback references {"url":"https://attacker.test"} | passed |
| catalog-service | unit | catalog-service/tests/unit/boundaries.test.ts | protects category, text, cast and year boundaries without silently dropping bad data | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes registra una película y protege los datos frente a mutaciones externas | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes acepta series sin duración ni recurso propio | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes permite 1→2→3, conserva el agregado previo y hace idempotente repetir estado | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza la transición 1→3 | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza la transición 2→1 | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza la transición 3→1 | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza la transición 3→2 | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes aplica PATCH parcial, limpia opcionales y conserva fechas/identidad | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"title":" "} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"releaseYear":1887} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"releaseYear":2025.5} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"genres":[1,1]} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"genres":[999]} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"languages":["1"]} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"durationMinutes":0} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"posterUrl":"javascript:alert(1)"} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"posterUrl":"https://user:password@example.com/image"} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"title":"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza una ficha inválida: {"publicationStatusId":2} | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes cuenta caracteres Unicode y normaliza conjuntos sin alterar el reparto | passed |
| catalog-service | unit | catalog-service/tests/unit/domain.test.ts | TítuloCatalogo y sus invariantes rechaza ObjectId como identificador público | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas rechaza operadores, campos internos e IDs como cadenas | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas valida tipo y bytes: text/plain {} | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas valida tipo y bytes: application/json { | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas valida tipo y bytes: application/json  | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas valida tipo y bytes: application/json "🌎🌎🌎" | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas cuenta bytes reales aunque Content-Length declare menos | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas oculta errores internos y correlaciona respuesta y log | passed |
| catalog-service | unit | catalog-service/tests/unit/http.test.ts | Contrato HTTP y protección de entradas elige códigos HTTP según los resultados confirmados del bulk | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado inicializa validadores e índices de forma idempotente | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado inserta y recupera un agregado sin cambiar su identidad | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado reconoce reintentos y no sobrescribe contenido por conflicto de importKey | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado reconcilia dos importaciones concurrentes con una sola inserción | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado resuelve repetidos del lote y rechaza grupos con contenido contradictorio | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado aplica PATCH real y rechaza una escritura con versión obsoleta | passed |
| catalog-service | integration | catalog-service/tests/integration/mongodb.test.ts | MongoCatalogRepository con MongoDB real aislado filtra por texto/categorías y limita la proyección paginada | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports requires identity before personal or ADMIN operations | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports returns real session DTOs through start/progress/pause/resume/complete and history | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports rejects caller identity injection, invalid positions and malformed route IDs | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports does not grant ADMIN ownership over another user's session | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports rejects USER asset access and permits ADMIN metadata and soft delete | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports maps missing/unpublished/catalog-down/storage-down start failures safely | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports validates the real multipart parser before attempting storage | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports sets CORS only for the allowed origin and returns retry metadata on quota exhaustion | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports health reports each actual dependency outcome without credentials | passed |
| playback-service | api | playback-service/tests/api/routes.test.ts | Actual Playback Route Handlers with controlled identity/repository ports returns a safe JSON failure even when container configuration cannot be constructed | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP interprets publication status 1 from the producer DTO | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP interprets publication status 2 from the producer DTO | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP interprets publication status 3 from the producer DTO | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP handles a producer series with no media reference | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP maps upstream HTTP 404 without exposing the body | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP maps upstream HTTP 500 without exposing the body | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP maps upstream HTTP 503 without exposing the body | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP rejects incompatible payload {} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP rejects incompatible payload {"tituloId":"wrong","publicationStatusId":2,"playbackReference":null} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP rejects incompatible payload {"tituloId":"ttl_cf0ed81e-3fc4-41e6-ba71-e52a6a298f45","publicationStatusId":"2","playbackReference":null} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP does not follow an upstream redirect | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP times out a real stalled HTTP connection | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → actual Catalog DTO over HTTP treats an opaque legacy catalog reference as unavailable media | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract accepts a real Users USER access token using public JWKS only | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract accepts a real Users ADMIN access token using public JWKS only | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"iss":"wrong"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"aud":"wrong"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"exp":1} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"sub":"usr_2b583c2c-2676-487f-84b8-ffcce577b93f"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"userId":"forged"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"role":"ROOT"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"role":["ADMIN"]} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"iat":"invalid"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"iat":1792617754} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"iat":1792614094} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"jti":42} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"jti":""} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible claims {"nbf":1792621294} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible headers {"kid":"unknown-key"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects incompatible headers {"typ":"NOT-JWT"} | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects an invalid signature while retaining the advertised kid | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects a JWKS with invalid RSA key material | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract fails closed when the JWKS endpoint is unavailable | passed |
| playback-service | contract | playback-service/tests/contract/gateways.test.ts | Playback → Users signing and JWKS contract rejects unsigned and symmetric algorithm confusion tokens | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set creates unique and query indexes reproducibly | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set enforces unique assets | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set rolls back all writes when outbox publication fails | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set serializes progress and persists completion only once under concurrency | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set uses the continue-watching index without collection scan | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set starts concurrently with only one current session and rejects the losing player's writes | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set orders, paginates and consolidates history by title without mixing user data | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set writes Started, Paused and Completed transactionally with owned identifiers | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set rolls back progress and pause when outbox fails after a session already exists | passed |
| playback-service | integration | playback-service/tests/integration/persistence.test.ts | Real MongoDB replica set shares atomic API quotas across concurrent callers and isolates identities | passed |
| playback-service | integration | playback-service/tests/integration/storage.test.ts | initializes a private bucket repeatedly, stores exact bytes and supports signed Range | passed |
| playback-service | integration | playback-service/tests/integration/storage.test.ts | rejects expired signed URLs and recognizes an object that has been removed | passed |
| playback-service | integration | playback-service/tests/integration/storage.test.ts | does not treat denied storage credentials as a missing object | passed |
| playback-service | unit | playback-service/tests/unit/config.test.ts | validates runtime config without leaking invalid secrets | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress rejects invalid position -1 | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress rejects invalid position NaN | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress rejects invalid position Infinity | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress rejects invalid position 123 | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Progress computes percentage and bounds tolerated overrun | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases starts ACTIVE and creates one event | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases allows REQUESTED -> ACTIVE | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases allows ACTIVE -> PAUSED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases allows ACTIVE -> COMPLETED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases allows ACTIVE -> FAILED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases allows PAUSED -> ACTIVE | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases allows PAUSED -> COMPLETED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects COMPLETED -> ACTIVE | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects FAILED -> ACTIVE | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects REQUESTED -> COMPLETED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects PAUSED -> FAILED | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects unpublished title | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases rejects missing asset | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases enforces ownership for progress and URL refresh | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases updates idempotently and emits only milestones | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases pauses, resumes and completes once; restart starts at zero | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases continues at persisted position and supersedes old session | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases excludes >=90 percent and isolates history | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases protects assets in use and requires admin | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases logical deletion retains bytes and prevents new sessions | passed |
| playback-service | unit | playback-service/tests/unit/playback.test.ts | Playback aggregate and use cases supersedes a paused session without introducing a forbidden state transition | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | rejects invalid persisted duration 0 | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | rejects invalid persisted duration -1 | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | rejects invalid persisted duration NaN | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | rejects invalid persisted duration Infinity | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | computes exact percentage 25 and continue-watching threshold | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | computes exact percentage 50 and continue-watching threshold | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | computes exact percentage 75 and continue-watching threshold | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | computes exact percentage 89.99 and continue-watching threshold | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | computes exact percentage 90 and continue-watching threshold | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | computes exact percentage 100 and continue-watching threshold | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | does not re-emit earlier milestones after a deliberate backward seek | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | refuses start when media bytes or the storage signing operation is unavailable | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | compensates successful storage upload when metadata insertion fails | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | does not report successful upload when compensation also fails | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | requires ADMIN before upload/storage writes and hides temporary paths in asset DTO | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | does not leak assets or sessions that do not exist | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | keeps logical deletion idempotent and blocks signing an unavailable asset | passed |
| playback-service | unit | playback-service/tests/unit/risks.test.ts | evaluates every state pair against the documented transition table | passed |

## E2E

| Caso | Navegador | Estado |
| --- | --- | --- |
| E2E-01 Register → Login → Home; authentication stays server-side | chromium | expected |
| E2E-02 Login → filtered catalog → detail → watchlist → My List → remove | chromium | expected |
| E2E-03 LIKE → DISLIKE persists after navigation | chromium | expected |
| E2E-04 real HTML5 MP4 → seek → pause → home → resume near saved position → complete | chromium | expected |
| E2E-05 ADMIN uploads a small MP4, verifies asset, publishes and edits a title | chromium | expected |
| E2E-06 expired signed JWT → concurrent refresh rotates exactly once → navigation continues | chromium | expected |
| E2E-07 Catalog unavailable shows a controlled error and recovers | chromium | expected |
| E2E-08 Playback unavailable preserves the application and permits recovery | chromium | expected |
| USER is denied administration and cross-site writes; expired session returns to login | chromium | expected |
| automatic signed media URL renewal preserves paused position | chromium | expected |
| profile, password revocation, account isolation and responsive layout | chromium | expected |
| logout clears browser session during an owned Redis outage | chromium | expected |
