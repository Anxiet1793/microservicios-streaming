# Lenguaje ubicuo

| Término | Significado en este proyecto |
| --- | --- |
| Usuario | Identidad pública usr_UUIDv4 independiente del bigint SQL |
| Perfil | Valor displayName/avatar/language del usuario |
| Mi Lista | Conjunto único usuario–tituloId para ver después |
| Preferencia | Señal explícita LIKE o DISLIKE; no algoritmo |
| Título | Película o serie con ficha editorial |
| REGISTRADO / PUBLICADO / RETIRADO | Estados editoriales 1 / 2 / 3 |
| Asset | Objeto MP4 propio de Playback, ast_UUIDv4 |
| Sesión de reproducción | Contexto de reproducción ses_UUIDv4 con propietario |
| Progreso consolidado | Última posición por usuario y título |
| Continuar viendo | Proyección IN_PROGRESS no completada y elegible |
| Outbox | Registro transaccional local de eventos, no broker |
| Refresh family | Grupo de rotaciones con revocación por replay |

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
