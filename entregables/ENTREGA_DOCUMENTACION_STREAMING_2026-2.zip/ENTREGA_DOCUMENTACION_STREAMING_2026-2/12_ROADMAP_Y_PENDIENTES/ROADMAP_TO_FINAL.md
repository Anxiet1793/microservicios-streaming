# Propuesta de trabajo hacia la evaluación final

No se encontró soporte documental que establezca un calendario oficial de semanas 9–16. La tabla es una propuesta retrospectiva de seguimiento, derivada de los riesgos y del dossier EP; debe validarla el equipo/docente.

| Semana propuesta | Trabajo pendiente | Evidencia de cierre esperada |
| --- | --- | --- |
| 9 | Rúbrica/formales, revocación externa y commit final | Documentos originales/constancia sin secretos/run GitHub |
| 10 | Dependencias MODERATE, rotación JWKS y cuotas Catalog | Audit y pruebas específicas |
| 11 | Cobertura BFF/player y CSP | Reporte por módulos/regresiones |
| 12 | Backup/restore SQL/Mongo/S3 | Restore aislado y smoke consistente |
| 13 | Carga/latencia/memoria y recuperación | Dataset y percentiles reales, sin inventar SLA |
| 14 | Firefox/WebKit y accesibilidad | Matriz de navegador/teclado/lector |
| 15 | Despliegue endurecido y observabilidad | TLS, permisos S3, SBOM, runbooks/alertas |
| 16 | Aceptación desde clon limpio y defensa | Commit/run/capturas/dossier actualizados |

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **PROPUESTA; NO CRONOGRAMA OFICIAL**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.
