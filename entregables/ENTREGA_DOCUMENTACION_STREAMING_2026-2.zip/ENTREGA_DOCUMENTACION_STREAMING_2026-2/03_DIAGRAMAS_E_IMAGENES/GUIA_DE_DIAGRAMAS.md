# Guía de diagramas

Los diagramas son ilustraciones técnicas derivadas del código y configuración, no capturas de ejecución. Todos tienen fuente Mermaid editable, SVG vectorial y PNG exportado. La notación C4 se representa mediante cajas/relaciones rotuladas, sin atribuir al proyecto una herramienta C4 de runtime. Las líneas punteadas y el rótulo FUTURO distinguen planificación; en el mapa de datos las referencias lógicas se señalan explícitamente.

## D01 C4 contexto del sistema

Introducción y alcance del sistema. No representa proveedores externos inexistentes.

Fuentes del repositorio: `frontend/src/app`, `docker-compose.yml`.

[Editable](editables/01.mmd) · [SVG](svg/01.svg) · [PNG](png/01.png)

## D02 C4 contenedores

Arquitectura de contenedores lógicos; cada API y almacén tiene propiedad separada.

Fuentes del repositorio: `docker-compose.yml`, `frontend/src/lib/server`, `playback-service/src/modules/playback/infrastructure/adapters.ts`.

[Editable](editables/02.mmd) · [SVG](svg/02.svg) · [PNG](png/02.png)

## D03 C4 componentes de Users

Capítulo de Clean/Hexagonal del servicio; dependencias de dominio hacia abstracciones, wiring en bootstrap.

Fuentes del repositorio: `src/modules/users`, `src/bootstrap`.

[Editable](editables/03.mmd) · [SVG](svg/03.svg) · [PNG](png/03.png)

## D04 C4 componentes de Catalog

Capítulo de Clean/Hexagonal del servicio; dependencias de dominio hacia abstracciones, wiring en bootstrap.

Fuentes del repositorio: `src/modules/catalog`, `src/bootstrap`.

[Editable](editables/04.mmd) · [SVG](svg/04.svg) · [PNG](png/04.png)

## D05 C4 componentes de Playback

Capítulo de Clean/Hexagonal del servicio; dependencias de dominio hacia abstracciones, wiring en bootstrap.

Fuentes del repositorio: `src/modules/playback`, `src/bootstrap`.

[Editable](editables/05.mmd) · [SVG](svg/05.svg) · [PNG](png/05.png)

## D06 Context Map DDD

Separar implementación de relaciones futuras; roles upstream/downstream son interpretación DDD documentada.

Fuentes del repositorio: `domain models`, `CatalogGateway`, `OutboxRepository`.

[Editable](editables/06.mmd) · [SVG](svg/06.svg) · [PNG](png/06.png)

## D07 Arquitectura general de integración

Vista técnica de APIs, almacenes y streaming de bytes; no hay lectura de base ajena.

Fuentes del repositorio: `docker-compose.yml`, `adapters.ts`, `session.ts`.

[Editable](editables/07.mmd) · [SVG](svg/07.svg) · [PNG](png/07.png)

## D08 Despliegue Docker e inicialización

Operación reproducible: healthy/completed, sin esperar un PRIMARY antes de configurar rs0.

Fuentes del repositorio: `docker-compose.yml`, `scripts/docker/init-playback-replica.js`.

[Editable](editables/08.mmd) · [SVG](svg/08.svg) · [PNG](png/08.png)

## D09 Bases de datos independientes

Capítulo Data Ownership; flechas punteadas son referencias de contrato, no FK.

Fuentes del repositorio: `schema.ts`, `catalog-document.ts`, `mongo.ts`.

[Editable](editables/09.mmd) · [SVG](svg/09.svg) · [PNG](png/09.png)

## D10 ERD Users PostgreSQL

Modelo relacional completo de aplicación: seis tablas, FK internas y PK compuestas.

Fuentes del repositorio: `users-service/src/modules/users/infrastructure/persistence/schema.ts`, `drizzle/0000_busy_carlie_cooper.sql`.

[Editable](editables/10.mmd) · [SVG](svg/10.svg) · [PNG](png/10.png)

## D11 Modelo documental Catalog

Modelo físico documental; colección episodios preparada no implica funcionalidad de reproducción de episodios.

Fuentes del repositorio: `catalog-document.ts`, `catalog-validators.ts`, `catalog-indexes.ts`.

[Editable](editables/11.mmd) · [SVG](svg/11.svg) · [PNG](png/11.png)

## D12 Modelo documental Playback

Persistencia de reproducción y atomicidad local; no son FK relacionales ni un broker.

Fuentes del repositorio: `playback-service/src/modules/playback/infrastructure/mongo.ts`, `domain/model.ts`.

[Editable](editables/12.mmd) · [SVG](svg/12.svg) · [PNG](png/12.png)

## D13 Secuencia registro y login

Mostrar separación de sesión de navegador y tokens entre servicios; la figura no contiene valores secretos.

Fuentes del repositorio: `Users RegisterUser/LoginUser`, `frontend/src/lib/server/session.ts`.

[Editable](editables/13.mmd) · [SVG](svg/13.svg) · [PNG](png/13.png)

## D14 Secuencia de reproducción

Flujo real; la verificación no implica consultar JWKS en cada petición.

Fuentes del repositorio: `StartPlaybackSession`, `CatalogGateway`, `MinioStorage`.

[Editable](editables/14.mmd) · [SVG](svg/14.svg) · [PNG](png/14.png)

## D15 Secuencia de progreso y continuidad

Explicar orden de escrituras, transacciones locales y retomar contenido.

Fuentes del repositorio: `PlaybackQueue`, `ChangePlayback`, `MongoUnitOfWork`.

[Editable](editables/15.mmd) · [SVG](svg/15.svg) · [PNG](png/15.png)

## D16 Flujo upload e importación publicación

Demostrar el flujo ADMIN y sus fronteras, sin inventar atomicidad distribuida.

Fuentes del repositorio: `UploadMediaAsset`, `BulkCreateCatalogTitles`, `ChangePublicationStatus`.

[Editable](editables/16.mmd) · [SVG](svg/16.svg) · [PNG](png/16.png)

## D17 Outbox actual y futuro de recomendaciones

Evitar afirmar que un Outbox es ya un bus o un servicio de recomendaciones.

Fuentes del repositorio: `OutboxEventPublisher`, `MongoUnitOfWork`, `no consumer project found`.

[Editable](editables/17.mmd) · [SVG](svg/17.svg) · [PNG](png/17.png)

## D18 Pipeline de calidad existente

Capítulo CI; configuración real separada de una ejecución remota no verificada.

Fuentes del repositorio: `.github/workflows/ci.yml`, `.github/workflows/quality.yml`.

[Editable](editables/18.mmd) · [SVG](svg/18.svg) · [PNG](png/18.png)

