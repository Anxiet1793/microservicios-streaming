# Expediente documental del proyecto streaming

Este paquete permite redactar el informe y preparar tablas, figuras y defensa de la plataforma **NÉVARO**. Curso y universidad son contexto proporcionado por el solicitante: Arquitectura de Microservicios, Ingeniería de Software, Universidad Autónoma del Perú, semestre 2026-2. No se verificó matrícula, integrantes ni rúbrica oficial.

Leer primero este archivo, RESUMEN_EJECUTIVO, ESTADO_ACTUAL y GUIA_PARA_EL_COMPAÑERO. Los archivos de arquitectura y datos son la síntesis vigente; los originales conservados pueden contener frases históricas como «Playback futuro» que ya no describen el corte actual.

## Convención de estados

**IMPLEMENTADO**: observado en código/configuración. **VERIFICADO MEDIANTE PRUEBA**: resultado ejecutado y conservado, con alcance/fecha. **DOCUMENTADO PERO NO VERIFICADO**: afirmación en un antecedente sin evidencia actual. **PLANIFICADO**: propuesta. **PENDIENTE**: acción o validación aún no resuelta. Una captura demuestra una pantalla concreta; no acredita toda la seguridad ni toda una suite.

## Cómo verificar

Abrir INDICE_DOCUMENTAL y el inventario CSV. Los originales intactos conservan SHA256 en ORIGINAL_FILES.json; un extracto sanitizado se identifica por separado en EXTRACTOS_SANITIZADOS.json. El manifiesto final incluye SHA256 de cada archivo del paquete; los originales duplicados se registran como alias en DUPLICADOS.json; las copias necesarias de assets HTML se explican en DUPLICADOS_PAQUETE.json. No hay ENV privados, tokens, cookies, dumps ni node_modules. El ZIP es un expediente, no un clon completo ejecutable; para repetir los tests se requiere el mismo working tree identificado por sus hashes, todavía no publicado como commit final.

El contexto vigente es este: 

| Componente | Estado | Alcance |
| --- | --- | --- |
| Frontend/BFF | VERIFICADO MEDIANTE PRUEBA | UI/SSR, composición, Redis, auth y panel ADMIN; E2E y capturas reales |
| Usuarios | VERIFICADO MEDIANTE PRUEBA | Perfil, sesiones, Mi Lista, LIKE/DISLIKE, PostgreSQL |
| Catálogo | VERIFICADO MEDIANTE PRUEBA | Películas/series como ficha, importación, publicación; MongoDB |
| Reproducción | VERIFICADO MEDIANTE PRUEBA | MP4 H264, sesiones, progreso, historial, S3 presignado |
| Episodios de series | IMPLEMENTADO PARCIAL | Colección/validador/índices preparados; sin API pública ni reproductor de episodios |
| Outbox | IMPLEMENTADO Y PROBADO LOCALMENTE | Escritura transaccional PENDING; no dispatcher ni entrega externa |
| Recommendations | PLANIFICADO | No proyecto, endpoint, algoritmo ni pantalla de recomendaciones calculadas |
| Payments | PLANIFICADO | No implementación ni transacciones de pago |
| Event Bus | PENDIENTE | Sin broker ni consumidor desplegado |
| API Gateway | PENDIENTE COMO SERVICIO INDEPENDIENTE | Existe BFF acotado en Next; no es un gateway general desplegado aparte |
| CI GitHub Actions | IMPLEMENTADO / REMOTO NO VERIFICADO | YAML y gates locales; consulta de runs disponible en evidencias |
| CD productivo | PLANIFICADO | Compose de desarrollo; no despliegue automático de producción acreditado |

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **SÍNTESIS BASADA EN FUENTES Y EVIDENCIAS**.

Fuentes de síntesis: inventario, contratos y evidencias trazadas en el índice documental. Las propuestas se identifican expresamente.

## Extraer y comprobar

Para evitar límites de rutas de Windows, extraer en una ruta corta, por ejemplo `C:\nevaro-docs`. Desde la carpeta raíz extraída ejecutar `python 13_MATERIAL_DE_REFERENCIA/verificar_paquete.py`. El script comprueba tamaños, SHA-256, faltantes y archivos adicionales sin red ni ENV. El manifiesto excluye su propio hash para evitar una referencia circular; el SHA-256 del ZIP final se entrega fuera del archivo. El inventario enumera todos los archivos, reservando referencias explícitas para sí mismo y el manifiesto.
