# Arquitectura general

El navegador consume una aplicación Next.js que combina React, SSR y BFF. El BFF valida rutas y orígenes, guarda tokens cifrados en Redis y solicita datos a Users, Catalog y Playback. Las APIs se despliegan separadamente y cada una posee su almacén. El acceso al MP4 usa una URL firmada de MinIO directamente desde el navegador.

Users emite JWT RS256 y publica JWKS. Catalog/Playback verifican firma y claims con la clave pública; no reciben la clave privada. Playback consulta el título por REST a Catalog, verifica publicación/referencia y luego consulta su propio asset. No existe transacción distribuida entre el catálogo y el objeto de video. La consistencia se maneja por referencias estables, controles locales y secuencia upload→importar→publicar.

La implementación sigue separación domain/application/infrastructure/interfaces con composición en bootstrap. Next y Zod se concentran en la interfaz/configuración; los adaptadores implementan puertos. Users/Catalog usan agregados inmutables; Playback modela su sesión mediante estado y transición. BFF no es un cuarto bounded context de negocio ni un API Gateway general.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [docker-compose.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/docker-compose.yml)
- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
- [frontend/src/lib/server/session.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/session.ts)
- [frontend/src/app/api/bff/[...path]/route.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/app/api/bff/[...path]/route.ts)
