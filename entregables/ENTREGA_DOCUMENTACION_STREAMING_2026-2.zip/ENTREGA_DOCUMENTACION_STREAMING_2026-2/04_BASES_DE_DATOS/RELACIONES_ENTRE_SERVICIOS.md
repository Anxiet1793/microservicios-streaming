# Relaciones entre servicios

`usr_UUIDv4` identifica al usuario fuera de PostgreSQL; las FK internas usan bigint. `ttl_UUIDv4` pertenece a Catalog y se almacena en Users/Playback solo como referencia. `ast_UUIDv4` pertenece a Playback; Catalog mantiene providerId/assetId/manifestKey. `ses_UUIDv4` identifica una sesión de Playback y no se confunde con sesión de autenticación.

No hay validación síncrona obligatoria de Catalog al agregar Mi Lista. El frontend puede encontrar referencias que ya no sean visibles y debe tratarlas como faltantes. Al iniciar Playback sí se consulta Catalog y se exige publicación/asset READY. Una serie no tiene asset propio. La consistencia entre publicar y borrar assets no es una transacción distribuida ni una FK S3.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
- [playback-service/src/modules/playback/infrastructure/adapters.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/infrastructure/adapters.ts)
