# Contratos distribuidos

Users→consumidores: JWT con sub/userId, role, authVersion cuando aplica, iss/aud/iat/exp/jti y kid; JWKS público RSA. La clave privada pertenece solo a Users. Verificadores no siguen URLs jku arbitrarias del token.

Playback→Catalog: GET de título por tituloId; el adapter convierte publicationStatusId=2 y playbackReference.assetId a su puerto CatalogGateway. Error 404 se traduce a TITLE_NOT_FOUND; indisponibilidad a error controlado. No consulta Catalog MongoDB.

Playback→MinIO: upload/delete/exists/presign mediante SDK, bucket privado. El navegador usa la URL firmada para bytes/Range; la API no envía toda la película. No almacenar URLs firmadas como identidad duradera.

BFF→Users/Catalog/Playback: rutas cerradas, tokens del servidor, timeout y rechazo de redirecciones. Composición enriquece tituloId a DTO de pantalla. No es un proxy arbitrario.

Futuro: Outbox→publisher→bus→Recommendations, y Payments/entitlements. Hoy ninguna de esas flechas transporta eventos reales.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [playback-service/src/modules/playback/infrastructure/adapters.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/infrastructure/adapters.ts)
- [frontend/src/lib/server/http.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/http.ts)
- [frontend/src/lib/server/catalog.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/src/lib/server/catalog.ts)
