# Seguridad del expediente compartido

La revisión final analiza el contenido del staging que se comprime, además del análisis previo del repositorio. Compara en memoria los secretos locales de ENV con cada texto, busca bloques de claves privadas, JWT, claves de API y URI con credenciales; inspecciona el ZIP embebido del reporte Playwright. No se escriben los valores buscados. Las capturas se revisaron visualmente.

No se incluyen ENV privados, cookies, storageState, dumps, claves privadas ni credenciales reales. **Un script de setup de Playback se entrega como EXTRACTO SANITIZADO**: la credencial local por defecto se sustituyó por un placeholder. No se alteró el archivo del repositorio. Su procedencia y los hashes de origen/derivado están en EXTRACTOS_SANITIZADOS.json; no figura como original intacto.

Los contratos y fuentes originales pueden contener cadenas ficticias de ejemplo o pruebas (p. ej. passwords de ejemplo y referencias a `process.env`), sin cuentas asociadas ni tokens utilizables. No deben reutilizarse como credenciales de un despliegue. Los ENV de ejemplo contienen placeholders; los runners generan secretos aleatorios por ejecución. La revisión diferencia estas cadenas didácticas de secretos reales, sin afirmar que un escáner demuestra ausencia absoluta de información sensible.

El hallazgo de una credencial en el historial Git requiere rotación externa por su propietario. Este expediente no contiene ese blob ni acredita su revocación.
