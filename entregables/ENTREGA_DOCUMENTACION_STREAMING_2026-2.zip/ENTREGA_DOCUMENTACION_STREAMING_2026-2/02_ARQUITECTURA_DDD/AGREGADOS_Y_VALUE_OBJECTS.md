# Agregados y valores

**Usuario** es una clase de agregado inmutable. `Profile` es un objeto validado/congelado, sin identidad independiente. Email, password y título se validan por funciones puras (`normalizeEmail`, `validatePassword`, `validateTitleId`), no por clases Email/Password inexistentes. IDs públicos tienen prefijo y UUIDv4.

**TituloCatalogo** es inmutable y restaura invariantes. `TituloId`, `FichaContenido`, `EstadoPublicacion` y `ReferenciaReproduccion` son clases de valor presentes en `domain/value-objects`. El aggregate mantiene fecha/versión y comprueba coherencia de tipo/duración/referencia.

**PlaybackSession** encapsula `Session` y valida propietario, sesión vigente, transición y progreso. `progress()` construye el valor de posición/duración/porcentaje. MediaAsset y ConsolidatedProgress son interfaces con repositorios propios; no afirmar inmutabilidad de todas ellas ni un DDD enriquecido que el código no contiene.

Los repositorios son puertos. Users usa PostgreSQL/Drizzle; Catalog usa MongoCatalogRepository; Playback implementa assets/sessions/progress/outbox con Mongo y UnitOfWork. Los Route Handlers conectan validación HTTP y casos de uso; el dominio no importa Next, ORM ni JWT.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [users-service/src/modules/users/domain/user.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/users-service/src/modules/users/domain/user.ts)
- [catalog-service/src/modules/catalog/domain/entities/catalog-title.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/catalog-service/src/modules/catalog/domain/entities/catalog-title.ts)
- [playback-service/src/modules/playback/domain/model.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/domain/model.ts)
- [playback-service/src/modules/playback/infrastructure/mongo.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/playback-service/src/modules/playback/infrastructure/mongo.ts)
