# Guía de reproducibilidad

Dentro de cada proyecto, con Node 24 y Docker disponibles:

```sh
npm ci
npm run lint
npm run typecheck
npm run test:coverage
npm run build
```

Backends: agregar `npm run docs:check` y build:scripts (Users/Playback) o build:init (Catalog). Frontend: `npx --no-install playwright install chromium`, luego `$env:CI='true'; npm run test:e2e` en PowerShell, o CI=true npm run test:e2e en Bash. Playback tests requieren la imagen MinIO construida desde su Dockerfile fijado. El job CI instala además las dependencias de Users/Catalog para contratos entre productores del mismo checkout.

La ejecución actual usa contenedores/credenciales de prueba propios. No configurar URLs de test con una base productiva ni correr la suite destructiva de caída de servicios sobre un stack compartido. Guardar exit codes, reportes y hashes. El corte académico identifica código sin commit final, por lo que HEAD solo no basta para reconstruirlo.

## Fuentes y alcance

Fecha del expediente: 21 de octubre de 2026. Estado: **IMPLEMENTADO; ver evidencia específica para las afirmaciones probadas**.

- [frontend/scripts/test-e2e.ts](../13_MATERIAL_DE_REFERENCIA/repositorio/frontend/scripts/test-e2e.ts)
- [.github/workflows/quality.yml](../13_MATERIAL_DE_REFERENCIA/repositorio/.github/workflows/quality.yml)

## Comprobación final de Docker

Después de encontrar Docker Desktop detenido, se inició en segundo plano y se repitieron compose up con espera de health y smoke. Resultado: 9 servicios running/healthy y 6 init finalizados con exit 0; smoke aprobado. Registro verificable: [RECHECK_FINAL.json](../09_EVIDENCIAS_DE_FUNCIONAMIENTO/Docker/RECHECK_FINAL.json). Los timestamps se conservan en UTC; el cierre corresponde al 21 de octubre de 2026 en America/Lima.

